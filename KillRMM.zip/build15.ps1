﻿<#
    @echo off
    echo -----------------------------------------------------------
    echo This script is not suitable for execution with CMD (Batch, Command Prompt, DOS Prompt).
    echo Please execute this script using PowerShell. If this system can't run PowerShell,
    echo please contact your Support delegate and ask for the Batch implementation of KillRMM.
    echo -----------------------------------------------------------
    pause
    exit 1

    KillRMM-PS :: build 15/seagull January 2024
    CentraKill, KillAEM, KillRMM, KillRMM-PS by seagull 2013-2024

    Please, DO NOT REDISTRIBUTE THIS BINARY.
    It has been provided to you by your Support delegate for your instance. It is not for public consumption.
#>

$host.ui.RawUI.WindowTitle="KillRMM-PS: Datto RMM Agent Uninstallation Tool"
$Host.UI.RawUI.BackgroundColor = 'Black'
[console]::WindowHeight=30
[console]::WindowWidth=100
clear

if ($env:CS_CC_HOST) {
    write-host "! ERROR: KillRMM-PS does not support execution via Component."
    write-host "  Please use the script in the manner it was supplied to you."
    exit 1
}

#============================================ FUNCTIONS and VARIABLES ============================================

#agent locations
$varDirProgData =(get-process -name AEMAgent   -ea 0).path | split-path -Parent -ea 0 | split-path -parent -ea 0
$varDirProgFiles=(get-process -name CagService -ea 0).path | split-path -Parent -ea 0

if ([intptr]::Size -eq 8) {
    $varProgramFiles=${env:ProgramFiles(x86)}
} else {
    $varProgramFiles=$env:ProgramFiles
}

function userConfirm ($module) {
    if ($varAuto) {
        write-host ": Automatic Mode: Removing $module"
        return $true
    } else {
        switch -regex ($(read-host "- Remove module $module`? (Y/N)")) {
            '^(y|Y|yes)$' {write-host ": Positive response: Uninstalling"   ; return $true}
             '^(n|N|no)$' {write-host ": Negative response: Skipping step"  ; return $false}
                  default {write-host ": No/invalid response: Skipping step"; return $false}
        }
    }
    $HOST.UI.RawUI.FlushInputBuffer()
}

#======================================================= CODE ====================================================

#check administrative rights
if (!($([bool](([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match "S-1-5-32-544")))) {
    write-host "! ERROR: Administrative rights required." -ForegroundColor Red
    switch -regex ($(read-host "  Press ENTER to restart as Admin")) {
        default {
            #write our current directory to a hard file since admin launches in sys32
            $pwd.path | out-file "$env:TEMP\~killRMM-PS.tmp"
            #relaunch the shell in admin-mode
            $newProcess = new-object System.Diagnostics.ProcessStartInfo "PowerShell"
            $newProcess.Arguments = "-executionpolicy bypass &'" + $script:MyInvocation.MyCommand.Path + "'"
            $newProcess.Verb = "runas"
            [System.Diagnostics.Process]::Start($newProcess)
            exit
        }
    }
} else {
    if (test-path "$env:TEMP\~killRMM-PS.tmp") {
        get-content "$env:TEMP\~killRMM-PS.tmp" | cd
        Remove-Item "$env:TEMP\~killRMM-PS.tmp" -Force
    }
}

#intro
write-host "Welcome to KillRMM-PS"
write-host "Administrative permissions confirmed" -ForegroundColor Cyan
write-host "==========================================="
write-host "- Bypass prompts with" -NoNewline
write-host " Automatic Mode " -NoNewline -ForegroundColor cyan
write-host "(" -NoNewline
write-host "[CAPS LOCK]" -NoNewline -ForegroundColor green
write-host "):    "

#display dialogue i
write-host `r
write-host "- Press [ESC] to quit without doing anything, or" -ForegroundColor Cyan
write-host "  Press any other key to proceed with uninstallation." -ForegroundColor Red

@"

PLEASE NOTE: This will remove EVERYTHING concerning Datto RMM, including
all logs and configuration data. If you still need this data, please back
it up outside of Datto RMM's working directories before running this tool.
(Some prompts will permit preservation of data, but do not rely on this.)

As this script is supplied in PS1 format it is assumed that the person
running it has performed their due diligence in scrutinising its contents.
Although none is expected, Datto/Kaseya will not be held responsible for 
any negative impact caused by the running of this tool script on a device.

By proceeding beyond this point you accept responsibility for this tool.
"@ | write-host

#display caps lock status
[Console]::SetCursorPosition(52,3)
do {
    if ([Console]::CapsLock) {
        write-host "Enabled " -ForegroundColor Red
        $varAuto=$true
    } else {
        write-host "Disabled" -ForegroundColor Cyan
        $varAuto=$false
    }
    Start-Sleep -Milliseconds 250
    [Console]::SetCursorPosition(52,3)
} until ([console]::KeyAvailable)
$varKey=([Console]::ReadKey($true)).key.value__

#display dialogue ii
[Console]::SetCursorPosition(0,4)
@"
                                                                             
                                                                             
                                                                             
                                                                             
                                                                             
                                                                             
                                                                             
                                                                             
                                                                             
                                                                             
                                                                             
                                                                             
                                                                             
                                                                             
                                                                             
                                                                             
"@ | write-host
[Console]::SetCursorPosition(0,4)
$HOST.UI.RawUI.FlushInputBuffer()
write-host "===========================================           "

#did the user press ESC?
switch ($varKey) {
    27 {
        write-host `r
        write-host ": ESC button pressed. Tool script will now exit."
        write-host "  No changes have been made to the system."
        start-sleep -seconds 3
        exit
    } default {
        #do nothing
    }
}

#display directories
write-host ": ProgramData Location:   " -NoNewline
if (!$varDirProgData) {
    write-host "Not Found: KillRMM-PS will remove known directories" -ForegroundColor Red
    $varDirProgData="$env:ProgramData\CentraStage"
} else {
    write-host "$varDirProgData" -ForegroundColor Cyan
}

write-host ": Program Files Location: " -NoNewline
if (!$varDirProgFiles) {
    write-host "Not Found: KillRMM-PS will remove known directories" -ForegroundColor Red
    $varDirProgFiles="$varProgramFiles\CentraStage"
} else {
    write-host "$varDirProgFiles" -ForegroundColor Cyan
}

write-host "==========================================="
write-host "- Delete Agent installation & system-level configuration directories" -ForegroundColor Green

#stop service
Stop-Service CagService -Force -ea 0
write-host ": Stopped CagService"
start-sleep -seconds 3

#infocyte
if (test-path "$varDirProgData\AEMAgent\RMM.AdvancedThreatDetection\agent.exe" -ea 0) {
    if (userConfirm "Infocyte HUNT Agent") {
        write-host "-------------------------------------------"
        start-process "$varDirProgData\AEMAgent\RMM.AdvancedThreatDetection\agent.exe" -ArgumentList "--uninstall" -NoNewWindow -Wait
        write-host ": Uninstalled Infocyte HUNT Agent"
        write-host "-------------------------------------------"
        start-sleep -seconds 5
    }
}

#run centrastage uninst.exe
if (test-path "$varDirProgFiles\Uninst.exe") {
    write-host ": Uninstalled Agent via uninstaller"
    start-process "$varDirProgFiles\Uninst.exe" -wait
}

#delete program files directory (mostly in case uninst.exe was absent)
write-host ": Deleted Agent directory (Program Files)"
remove-item $varDirProgFiles -Recurse -Force -ea 0 | Out-Null

#kill processes, none of which should be running
("gui","CagService","AEMAgent","Aria2c","LibreHardwareMonitor","RMM.WebRemote","RMM.AdvancedThreatDetection") | % {
    Stop-Process -name $_ -Force -ea 0
    if ($?) {
        write-host ": Stopped $_.exe"
    }
}
start-sleep -seconds 5

#kill system-level directories
("System32\Config\SystemProfile\AppData\Local\CentraStage","SysWOW64\Config\SystemProfile\AppData\Local\CentraStage","Temp\.net") | % {
    if (test-path "$env:SystemRoot\$_") {
        remove-item "$env:SystemRoot\$_" -Force -Recurse | Out-Null
        write-host ": Removed directory at $env:SystemRoot\$_"
    }
}

write-host "==========================================="
write-host "- Delete Agent device-level configuration directories" -ForegroundColor Green

$varKey=userConfirm "Agent Approval Key"
gci "$(split-path $varDirProgData)\CentraStage*" | % {
    if ($varKey) {
        <# reset permissions to grant us DELETE access to the "key" file.
           if the user doesn't consent to this, delete actions will fail, which is what they wanted.
           new internationalised version for 2024 to use `/d j` instead of `/d y` for german systems.
           likely other languages will demand their own localised flags as well.
           microsoft, quick word: WHAT WERE YOU THINKING?! do you want people to write scripts for windows or not?! #>

        takeown /f $_ /r /d y 2>&1>$null
        if (!$?) {takeown /f $_ /r /d j | out-null}
        icacls "$_\*" /q /c /t /reset | Out-Null
    }

    #delete the files and then their parent folders from $env:ProgramData
    gci $_ -Recurse | ? {!($_.PSIsContainer)} | % {remove-item $_.FullName -Force -ea 0}
    remove-item $_.FullName -Force -Recurse -ea 0
    write-host ": Removed directory at $($_.FullName)"
    if ($varKey) {
        #no point attempting to remove the CentraStage folder unless we know we had full access to it
        remove-item "$_" -Force -Recurse -ea 0
    } 
}

write-host "==========================================="
write-host "- Delete Agent user-level configuration directories" -ForegroundColor Green

if (userConfirm "User configuration (RDP passwords etc)") {
    gci $($env:public | split-path) | ? {$_.PSIscontainer} | % {
        remove-item "$($_.FullName)\AppData\Local\CentraStage" -Force -Recurse -ea 0
        if ($?) {
            write-host ": Removed user-level configuration data for user $_."
        }
    }
}

write-host "==========================================="
write-host "- Delete Agent Registry data" -ForegroundColor Green

#keys
remove-item "Registry::HKEY_CLASSES_ROOT\cag" -Force -Recurse -ea 0
remove-item "HKLM:\Software\CentraStage" -Force -Recurse -ea 0
write-host ": Deleted HKLM and HKCR CentraStage/CAG Registry keys"

#values
Remove-ItemProperty "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run" -Name "CentraStage" -Force -ea 0
Remove-ItemProperty "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run" -Name "Panda Cloud Systems Management" -Force -ea 0
Remove-ItemProperty "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run" -Name "CentraStage" -Force -ea 0
Remove-ItemProperty "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run" -Name "Panda Cloud Systems Management" -Force -ea 0
write-host ": Deleted CentraStage startup Registry values"

write-host "==========================================="
write-host "- Remove Splashtop" -ForegroundColor Green

if (userConfirm "Splashtop Streamer/Viewer/Updater") {
    ("HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall","HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall") | % {
        gci -Path $_ -ea 0 | % { Get-ItemProperty $_.PSPath } | ? { $_.DisplayName -match "Splashtop" } | ? {$_.PSChildName -match '}$'} | % {
	    start-process "msiexec" -argumentlist "/x$($_.PSChildName) /qn" -wait
        write-host ": Uninstalled $($_.DisplayName)"
        }
    }
    if (test-path "$varProgramFiles\Splashtop\Splashtop Software Updater\uninst.exe") {
        start-process "$varProgramFiles\Splashtop\Splashtop Software Updater\uninst.exe" -ArgumentList "/S" -wait
        write-host ": Uninstalled Splashtop Software Updater"
    }

    remove-item "$env:ProgramData\Splashtop" -Force -Recurse -ea 0
    write-host ": Removed Splashtop ProgramData folder"

    gci $($env:public | split-path) | ? {$_.PSIscontainer} | % {
        remove-item "$($_.FullName)\AppData\Local\Splashtop" -Force -Recurse -ea 0
        if ($?) {
            write-host ": Removed user-level Splashtop data for user $_."
        }
    }

}

write-host "==========================================="
write-host "- Complete Datto RMM Agent uninstallation complete." -ForegroundColor Cyan
write-host "  Tool will now exit."
if ([console]::CapsLock) {
    write-host "  Don't forget to turn caps lock off!" -ForegroundColor Red
}
write-host `r
cmd /c pause

<#
    due diligence performed. thanks for meeting us halfway.
    - seagull, august 2023
#>