﻿$varTitle="Agent Health Check v2.2.296" #december 2025

<#
    Datto RMM Health Check Tool/Standalone version :: Written by seagull, 2017-2025
    this tool may not be redistributed outside of official kaseya channels.
    this tool is NOT open-source and has NOT been released under public licence.
#>

#component check
if ($env:cs_profile_name) {
    write-host "This interactive script does not support being run as a Component."
    write-host "A Componentised version of this script is available from the ComStore"
    write-host "under the name 'Agent Health Direct-Check [WIN]'."
    exit 1
}

#cosmetix
$host.ui.RawUI.WindowTitle = "Datto RMM " + $varTitle #give it a title
$Host.UI.RawUI.BackgroundColor = 'Black'              #paint the screen black
clear

# =========================================================== VARIABLES & FUNCTIONS ===========================================================

#configure net
[System.Net.ServicePointManager]::SecurityProtocol=[Enum]::ToObject([System.Net.SecurityProtocolType], 3072)
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}

if (([IntPtr]::size) -eq 4) {
    $varProg32=$env:ProgramFiles
    $CSRegSoftware='HKLM:\Software'
} else {
    $varProg32=${env:ProgramFiles(x86)}    
    $CSRegSoftware='HKLM:\Software\WOW6432Node'
}

$varScriptDir = split-path -parent $MyInvocation.MyCommand.Definition
$CSAdmin=([bool](([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match "S-1-5-32-544"))

try {
   $varWMIOut=gwmi Win32_OperatingSystem -ea Stop
   [int]$varWinVer=$varWMIOut.buildNumber
   [int]$varSKU=$varWMIOut.operatingSystemSKU
   $varCaption=$varWMIOut.caption
   $varLastBootWMI=$varWMIOut.lastBootUpTime
} catch {
   write-host "! ERROR: Unable to enumerate device WMI." -ForegroundColor Red
   write-host "  This will cause some errors to appear; please attempt to fix the WMI on page two."

   #flag WMI issues
   $varWMIIssues="Significant"

   #highlight issues in log
   [int]$varWinVer=0
   [int]$varSKU=0
   $varCaption="Unknown Windows Device (WMI dysfunctional)"
   $varLastBootWMI=0
}

#get the programdata directory, which is less straightforward than you'd think
if (get-process -name AEMAgent -ea 0) {
    $CSProgData=(get-process -name AEMAgent -ea 0).path | split-path -Parent -ea 0 | split-path -parent -ea 0
    $CSDataLog=get-content "$CSProgData\AEMAgent\DataLog\aemagent.log" -encoding UTF8 -ea 0
} else {
    $CSDataLog=get-content "$env:ProgramData\CentraStage\AEMAgent\DataLog\aemagent.log" -encoding UTF8 -ea 0
}

Function EpochTime {
    [int][double]::Parse((Get-Date -UFormat %s))
}

function makeFolder {
    $script:varResultDir = "$varScriptDir\AHC-$env:computername-Result-$(EpochTime)"
    new-item "$varResultDir\" -type directory -Force | out-null
}

function Get-HTTPHeaders { # by geoff varosky/sharepointyankee.com
    param( 
        [Parameter(ValueFromPipeline=$true)] 
        [string] $Url 
    )

    $request = [System.Net.WebRequest]::Create( $Url ) 
    $headers = $request.GetResponse().Headers 
    $headers.AllKeys | 
         Select-Object @{ Name = "Key"; Expression = { $_ }}, 
         @{ Name = "Value"; Expression = { $headers.GetValues( $_ ) } }
}

function makeHTTPRequest ($tempHost, $response, $response2) { #v7 even-more-divergent variant
    $tempRequest = [System.Net.WebRequest]::Create($tempHost)
    if ($env:CS_PROFILE_PROXY_TYPE -ge '1') {
        getProxy
        $tempRequest.Proxy = New-Object System.Net.WebProxy("$script:varProxyLoc`:$script:varProxyPort",$true)
    }

    #try three times
    while ($attempts -ne 3) {
        try {
            $tempResponse=$tempRequest.getResponse()
            $TempReturn=($tempResponse.StatusCode -as [int])
        } catch [System.Exception] {
            $tempReturn=$_.Exception.Response.StatusCode.Value__
        }

        $attempts++
        if (($tempReturn -as [string]).length -eq 3) {break}
    }

    #anti-throttling
    start-sleep -seconds 2

    if ($tempReturn -eq $response -or $tempReturn -eq $response2) {
        return $true
    } else {
        return $false
    }
}

function makeIPRequest ($tempHostArray, $tempName, $tempSuffix) { #unique variant for testing CCs specifically
    $tempTotal=(($tempHostArray.split())|measure-object).count
    foreach ($tempHost in $tempHostArray.split()) {
        $tempIPRequest=new-object net.sockets.tcpclient
        if ($tempSuffix) {
            $tempIPRequest.beginConnect($("$temphost"+"$tempsuffix"),443,$Null,$Null ) | Out-Null
        } else {
            $tempIPRequest.beginConnect("$tempHost",443,$null,$null) | Out-Null
        }

        While (-not $tempIPRequest.Connected) {
            $attempts++
            start-sleep -seconds 1
            if ($attempts -ge 5) {break}
        }

        if ($tempIPRequest.Connected) {
            $tempPass++
            if ($tempSuffix) {
                $script:CSToolReport+="+ SUCCESS: $tempName $("$tempHost"+"$tempSuffix")"
            } else {
                $script:CSToolReport+="+ SUCCESS: $tempName $tempHost"
            }
        } else {
            if ($tempSuffix) {
                $script:CSToolReport+="! FAILURE: $tempName $("$tempHost"+"$tempSuffix")"
            } else {
                $script:CSToolReport+="! FAILURE: $tempName $tempHost"
            }
        }
        $tempIPRequest.close()
        Clear-Variable $attempts -ea 0
    }

    #tally the results
    if ($tempPass -ne $tempTotal) {
        return $false
    } else {
        return $true
    }
}

function processIPList ($tempHostArray, $tempHeader, $tempFailsMax, $tempLabel) { #unique variant for testing tunnel/platform IP lists specifically
    $tempTotal=(($tempHostArray)|measure-object).count
    $tempPass=0
    foreach ($tempHost in [array]$tempHostArray) {
        #perform the check
        $tempIPRequest=new-object net.sockets.tcpclient
        $tempIPRequest.BeginConnect($tempHost,443,$Null,$Null) | Out-Null
        start-sleep -milliseconds 300
        if ($tempIPRequest.Connected) {
            #successful connection, increment the readout
            $tempPass++

            #if we need to, add a zero to single-digit figures to preserve spacing
            if (($tempTotal -as [string]).length -eq 2) {
                if (($tempPass -as [string]).length -eq 1) {
                    $tempPassStr="0"+$tempPass
                } else {
                    $tempPassStr=$tempPass
                }
            } else {
                $tempPassStr=$tempPass
            }

            #update the readout
            write-host "`r$tempHeader [$tempPassStr/$tempTotal]" -NoNewline
            $script:CSToolReport+=" + OK: $tempLabel ($tempHost)"
        } else {
            $script:CSToolReport+=" ! NO: $tempLabel ($tempHost)"
        }
        $tempIPRequest.close()
    }

    #tally the results
    write-host "`r$tempHeader " -NoNewline
    if ($tempPass -eq $tempTotal) {
        write-host "[$tempPassStr/$tempTotal]" -ForegroundColor Green -NoNewline
        $script:CSToolReport+="+ SUCCESS: 100% of IP addresses were contactable"
    } elseif ($tempPass -ge ($tempTotal*0.25)) {
        write-host "[$tempPassStr/$tempTotal]" -ForegroundColor Yellow -NoNewline
        $script:CSToolReport+="+ SUCCESS: At least 25% of IP addresses were contactable (this is typical)"
    } else {
        write-host "[$tempPassStr/$tempTotal]" -ForegroundColor Red -NoNewline
        $script:CSToolReport+="! FAILURE: Fewer than 25% of IP addresses were contactable."
    }
}

function toSHA256 {
	param ([Parameter(ValueFromPipeline=$true)]$string)
	-Join ($([System.Security.Cryptography.SHA256]::Create()).ComputeHash((New-Object IO.StreamReader $input).BaseStream) | ForEach {"{0:x2}" -f $_})
}

function getGUID2 ($softwareTitle) { #returns display name, not parent key/MSI GUID
    ("HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall","HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall") | % {
        try {
            gci -Path $_ -ea 0| % {gp $_.PSPath -ea 0} | ? {$_.DisplayName -match $softwareTitle} | % {
                return $_.DisplayName
            }
        } catch {
            return $null
        }
    }
}

# ==================================================================== PAGE ONE ===================================================================

write-host "Page 1: Platform Connectivity" -ForegroundColor Green
write-host "Started @ $(Get-Date)" -ForegroundColor Cyan
write-Host "============================="

#------------------------------------------------ sub-section: script update check

[xml]$CSToolVer_XML=(New-Object System.Net.WebClient).DownloadString("https://storage.centrastage.net/version.xml")

if (!$CSToolVer_XML) {
    write-host 'Could not check tool version. Please whitelist https://storage.centrastage.net.' -ForegroundColor Red
    write-host `r
} else {
    if ($CSToolVer_XML.seagull.build -notmatch $varTitle) {
        write-host "Agent Health Check Tool is out of date." -ForegroundColor Red
        write-host 'Download the latest build from: ' -NoNewline
        write-host 'http://dat.to/ahcdl' -ForegroundColor Cyan
        cmd /c pause
        write-host `r
    }
}

#------------------------------------------------ sub-section: check (administrative) privilege

if (!$CSAdmin) {
    $varOnDemand=0
    write-host "Script is not being run as an Administrator." -ForegroundColor Red
    write-host "Re-launch as Admin to enable gathering/analysis of Agent operational data?"
    write-host "(This may not work if the Health Check Tool file is on a Network Drive!)"
    write-host "[ENTER]" -NoNewline -foregroundcolor Red; write-host "/No, " -NoNewline; write-host "[A]" -NoNewline -foregroundcolor Red; write-host "/Yes: " -NoNewline
    $choiceInput = read-host
    switch -Regex ($choiceInput) {
        default {
            #do nothing
        } 'A|a|Y|y' {
            #write our current directory to a hard file since admin launches in sys32
            $pwd.path | out-file "$env:TEMP\~AEMHC.tmp"
            #relaunch the shell in admin-mode
            $newProcess = new-object System.Diagnostics.ProcessStartInfo "PowerShell";
            $newProcess.Arguments = "-executionpolicy bypass &'" + $script:MyInvocation.MyCommand.Path + "'"
            $newProcess.Verb = "runas";
            [System.Diagnostics.Process]::Start($newProcess);
            exit
        }
    }
    write-host "`r"
} else {
    #congratulate the user
    write-host "Administrative permissions confirmed." -ForegroundColor Cyan
    write-host "`r"
    #search for the .tmp file; if it is found, load it, then delete it
    if (test-path "$env:TEMP\~AEMHC.tmp") {
        get-content "$env:TEMP\~AEMHC.tmp" | cd
        Remove-Item "$env:TEMP\~AEMHC.tmp"
        $varScriptDir = $pwd.path
    }
    #40HC89: load agent XML files into memory NOW so we can check to see if device is onDemand :: [0] unknown [1] disabled [2] enabled :: MY KINGDOM FOR NATIVE TERNARY LOGIC
    $arrXMLFiles=@()
    $arrXMLFiles+=$((Get-ChildItem -Path "$env:SystemRoot\System32\config\systemprofile\AppData\Local\CentraStage" -Filter 'user.config' -recurse -force -ea 0 | select -last 1).FullName)
    $arrXMLFiles+=$((Get-ChildItem -Path "$env:SystemRoot\SysWOW64\config\systemprofile\AppData\Local\CentraStage" -Filter 'user.config' -recurse -force -ea 0 | select -last 1).FullName)

    if (($arrXMLFiles | ? {$_}).count -ge 1) {
        if ((((get-content $arrXMLFiles[0] -EA stop) -as [xml]).configuration.userSettings."CentraStage.Cag.Core.Settings".setting | ? {$_.Name -eq 'OnDemand'}).Value -eq 'true') {
            $varOnDemand=2
        } else {
            $varOnDemand=1
        }
    } else {
        $varOnDemand=0
    }
}

#------------------------------------------------ sub-section: check powershell constrained language mode

if ($ExecutionContext.SessionState.LanguageMode.value__ -ne 0) {
	write-host "! NOTICE: PowerShell Constrained-language mode is enabled for this device." -foregroundcolor Red
	write-host "  Whilst Datto RMM will co-operate with this setting, ComStore Components in toto are"
	write-host "  not written for this mode and may not be compatible with it, leading to issues."
	write-host "  This tool does not play well with Constrained-language mode and thus has been halted."
	write-host `r
	write-host "  If Constrained-language mode has been enabled due to security concerns,"
	write-host "  please ensure your understanding of the setting confers with Microsoft's."
	write-host "  For some partners, enabling this setting will cause more issues than it resolves."
	write-host "  More: https://devblogs.microsoft.com/powershell/powershell-constrained-language-mode/"
	write-host `r
	write-host "  Execution halted: tool is not compatible with system running state." -foregroundcolor Cyan
	cmd /c pause
	exit
}

#------------------------------------------------ sub-section: confirm platform

#write basic information to the report
$script:CSToolReport=@()
$script:CSToolReport+= "$varTitle`: Verbose Output Log"
$script:CSToolReport+= "=================================="
$script:CSToolReport+= ": Endpoint Hostname:                $env:computername"
$script:CSToolReport+= ": Endpoint Windows Version:         Build $varWinver / $varCaption"
$script:CSToolReport+= ": Date/Time of Tool Execution:      $(Get-Date) :: $((Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\TimeZoneInformation").TimeZoneKeyName)"

#write agent state to the report
if ($varOnDemand -eq 1) {
    $script:CSToolReport+= ": Agent State (Managed/OnDemand):   Managed - all checks will be performed"
} elseif ($varOnDemand -eq 2) {
    $script:CSToolReport+= ": Agent State (Managed/OnDemand):   OnDemand - some checks will be omitted"
} else {
    $script:CSToolReport+= ": Agent State (Managed/OnDemand):   Unknown - some checks may be omitted (Log files may be absent or tool is not being run as Admin)"
}

write-host "                              -== Connectivity Check ==-" -foregroundcolor Green
write-host `r
if (Test-Path "$varProg32\CentraStage\CagService.exe.config") {
    write-host "                   [ENTER]" -ForegroundColor Green -NoNewline; write-host " Infer platform from Agent installation"
}
write-host "      1" -ForegroundColor Green -NoNewline; write-host " Pinotage (EMEA West 1) " -ForegroundColor White -NoNewline
write-host "|" -ForegroundColor DarkGray -NoNewline; write-host " 2" -ForegroundColor Green -NoNewline; write-host " Merlot (EMEA West 2) " -ForegroundColor White -NoNewline
write-host "|" -ForegroundColor DarkGray -NoNewline; write-host " 3" -ForegroundColor Green -NoNewline; write-host " Syrah (Asia-Pacific) " -ForegroundColor White
write-host "         4" -ForegroundColor Green -NoNewline; write-host " Zinfandel (US West) " -ForegroundColor White -NoNewLine
write-host "|" -ForegroundColor DarkGray -NoNewline; write-host " 5" -ForegroundColor Green -NoNewline; write-host " Concord (US East 1)  " -ForegroundColor White -NoNewLine
write-host "|" -ForegroundColor DarkGray -NoNewline; write-host " 6" -ForegroundColor Green -NoNewline; write-host " Vidal (US East 2)" -ForegroundColor White
write-host `r

#get the platform from the user
while (!$varPlatform) {
    $HOST.UI.RawUI.FlushInputBuffer()
    $varPlatPrompt=read-host "Please choose your RMM platform or region"
    switch ($varPlatPrompt) {
        default {
            if (Test-Path "$varProg32\CentraStage\CagService.exe.config") {
                $varPlatform=($((get-content "$varProg32\CentraStage\CagService.exe.config" -EA stop) -as [xml]).configuration.applicationSettings."CentraStage.Cag.Core.AppSettings".setting | ? {$_.Name -eq 'CsIp'}).Value
            } else {
                write-host "! ERROR: No Agent software is installed (or its configuration could not be loaded)."
                write-host "  Please either manually select your platform or re-install the Agent and try again."
            }
        } 1 {
            $varPlatform='01cc'
        } 2 {
            $varPlatform='02cc'
        } 3 {
            $varPlatform='syrahcc'
        } 4 {
            $varPlatform='03cc'
        } 5 {
            $varPlatform='concord'
        } 6 {
            $varPlatform='vidal'
        }
    }
}

#furnish the details :: we have to break it up like this because of the 'null' option
switch -regex ($varPlatform) {
      '^01cc' {
        $varCC_Name=   "Pinotage"
        $varCC_NameAlt=$null
        $arrCC_CC=     "01cc"
    } '^02cc' {
        $varCC_Name=   "Merlot"
        $varCC_NameAlt="-merlot"
        $arrCC_CC=     "02cc"
    } '^03cc' {
        $varCC_Name=   "Zinfandel"
        $varCC_NameAlt="-zinfandel"
        $arrCC_CC=     "03cc"
    } 'syrah' {
        $varCC_Name=   "Syrah"
        $varCC_NameAlt="-syrah"
        $arrCC_CC=   @("syrahcc","01syrahcc")
    } 'concord' {
        $varCC_Name=   "Concord"
        $varCC_NameAlt="-concord"
        $arrCC_CC=   @("concordcc","01concordcc")
    } 'vidal' {
        $varCC_Name=   "Vidal"
        $varCC_NameAlt="-vidal"
        $arrCC_CC=   @("vidalcc","01vidalcc")
    } default {
        write-host "! ERROR: No platform selection was passed across."
        write-host "  PARTNERS:  Please report this error."
        write-host "  EMPLOYEES: The tool doesn't work on internal servers."
        cmd /c pause
        exit 1
    }
}

write-host "Platform Selected: " -ForegroundColor DarkGray -NoNewline; write-host "$varCC_Name" -ForegroundColor White
write-host `r

#------------------------------------------------ sub-section: the Business End

$script:CSToolReport+=": Datto RMM Platform:               $varCC_Name"
$script:CSToolReport+="=================================="
$script:CSToolReport+=""
$script:CSToolReport+="= Connectivity Scan results for Datto RMM Host-based services:"

#web portal & graphQL API (CSM deprecated)
write-host "     Web Portal                 " -nonewline

if (makeHTTPRequest $("https://$varCC_Name"+"rmm.centrastage.net") 403) {
    $varPortalSuccess++
    $script:CSToolReport+="+ SUCCESS: Web Portal               $("https://$varCC_Name.rmm.datto.com")"
} else {
    $script:CSToolReport+="! FAILURE: Web Portal               $("https://$varCC_Name.rmm.datto.com")"
}

if (makeIPRequest "$varCC_Name-frontend-api.centrastage.net" "Web Portal GraphQL API  ") {
    $varPortalSuccess++
}

if ($varPortalSuccess -ge 2) {
    Write-Host "    OK!" -ForegroundColor Green -NoNewline
} else {
    Write-host " Failed" -ForegroundColor Red -NoNewline
}

write-host "   ||   " -foregroundcolor DarkGray -nonewline

#monitoring service
write-host "Monitoring Service          " -nonewline
If (makeHTTPRequest "https://$varCC_Name-monitoring.centrastage.net/device/1234/monitor" 200) { 
    Write-Host "   OK!" -ForegroundColor Green
    $script:CSToolReport+="+ SUCCESS: Monitoring Service       https://$varCC_Name-monitoring.centrastage.net"
} else {
    Write-host "Failed" -ForegroundColor Red
    $script:CSToolReport+="! FAILURE: Monitoring Service       https://$varCC_Name-monitoring.centrastage.net"
}

#------------------------------------------------ sub-section: cypher/CC connectivity check

write-host "     Control Channel             " -NoNewline

#first, check to see if all the cyphers required for CC connections are enabled
if ($CSAdmin) {
    [int]$varCypherSuccess=0
    $arrCyphersY=@()
    [System.Collections.ArrayList]$arrCyphersN="WoW:256CBC384","WoW:128CBC256","WoW:256GCM384","WoW:128GCM256","Ntv:256CBC384","Ntv:128CBC256","Ntv:256GCM384","Ntv:128GCM256"
    "HKLM:\Software\WOW6432Node","HKLM:\Software" | % {
        if ($_ -match '6432') {$prefix='WoW'} else {$prefix='Ntv'}
        try {
            ((get-itemproperty "$_\Policies\Microsoft\Cryptography\Configuration\SSL\00010002" -ea stop).Functions) -split ',' | % {
                #if the key isn't defined, throw
                if ([string]::IsNullOrWhiteSpace($_)) {throw}
                #key is defined; what's in it
                switch -regex ($_) {
                    '^TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384($|_)' {
                        $varCypherSuccess++
                        $arrCyphersN.Remove("$prefix`:256CBC384")
                        $arrCyphersY+="$prefix`:256CBC384"
                    } '^TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256$($|_)' {
                        $varCypherSuccess++
                        $arrCyphersN.Remove("$prefix`:128CBC256")
                        $arrCyphersY+="$prefix`:128CBC256"
                    } '^TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256$($|_)' {
                        $varCypherSuccess++
                        $arrCyphersN.Remove("$prefix`:128GCM256")
                        $arrCyphersY+="$prefix`:128GCM256"
                    } '^TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384$($|_)' {
                        $varCypherSuccess++
                        $arrCyphersN.Remove("$prefix`:256GCM384")
                        $arrCyphersY+="$prefix`:256GCM384"
                    }
                }
            }
        } catch {
            $varCypherSuccess+=4 #if nothing's been configured, the defaults will see us through
        }
    }
    
    if ($varCypherSuccess -lt 1) {
        #no good cypher enabled :: throw the check
        write-host "Cypher" -ForegroundColor Red -NoNewline
        $script:CSToolReport+="! FAILURE: Device does not have appropriate Cyphers enabled to facilitate a TLS connection to the Control Channel."
        $script:CSToolReport+="           Please ensure this device is still supported by Microsoft and has the latest updates and patches installed."
        $script:CSToolReport+="           If this error persists after doing this, please speak with Support and/or enable the Cyphers with the IISCrypto tool."
    } else {
        #at least one good cypher enabled :: perform the check
        if ($varCypherSuccess -lt 8) {
            if ([intptr]::Size -eq 4) {$varCypherSuccess-=4} #cosmetic compensation for the four erroneous WOW6432NODE passes on x86
            $script:CSToolReport+=": NOTICE: Device does not have all Cyphers enabled to facilitate a TLS connection to the Control Channel."
            $script:CSToolReport+="          The total amount of necessary Cyphers that were enabled was $varCypherSuccess out of a possible $([intptr]::Size)."
            $script:CSToolReport+="          Cyphers missing (TLS_ECDHE_RSA_WITH_AES): $($arrCyphersN -as [string])"
            $script:CSToolReport+="          Cyphers present (TLS_ECDHE_RSA_WITH_AES): $($arrCyphersY -as [string])"
            $script:CSToolReport+="          If the Agent is not connecting reliably or at all, please speak with Support and/or re-enable the Cyphers with the IISCrypto tool."
        } else {
            $script:CSToolReport+="+ SUCCESS: Device has necessary TLS Cyphers installed to facilitate Control Channel connection."
        }

        #actually check the connection :: try up to three times
        $varCounter=0
        while ($varCounter -lt 3) {
            if (makeIPRequest "$arrCC_CC" "Control Channel         " ".centrastage.net") {
                $varCCCheck++
                $varCounter=99
            } else {
                start-sleep -seconds 5
                $varCounter++
            }
        }

        if ($varCounter -eq 99) {
            write-host "   OK!" -ForegroundColor Green -NoNewline
        } else {
            write-host "Failed" -ForegroundColor Red -NoNewline
        }
    }
} else {
    write-host " Admin" -ForegroundColor Red -NoNewline
    $script:CSToolReport+="! NOTICE: Unable to gauge Control Channel connectivity: No admin access to check connection cyphers."
}

write-host "   ||   " -foregroundcolor DarkGray -nonewline

#audit service
write-host "Audit Service               " -NoNewline
if (makeHTTPRequest "https://$varCC_Name-audit.centrastage.net/cs/version" 200) {
    Write-Host "   OK!" -ForegroundColor Green
    $script:CSToolReport+="+ SUCCESS: Audit service            https://$varCC_Name-audit.centrastage.net"
} else {
    Write-host "Failed" -ForegroundColor Red
    $script:CSToolReport+="! FAILURE: Audit service            https://$varCC_Name-audit.centrastage.net"
}

#=============================================== new line ===============================================

#ts
write-host "     Local Tunnel Server         " -NoNewline
if (makeIPRequest "ts.centrastage.net" "Local Tunnel Server     ") {
    write-host "   OK!" -ForegroundColor Green -NoNewline
} else {
    write-host "Failed" -ForegroundColor Red -NoNewline
}

write-host "   ||   " -foregroundcolor DarkGray -nonewline

#real-time
write-host "Real-time Service           " -nonewline
if (makeHTTPRequest "https://$varCC_Name-realtime.centrastage.net/notifications/test" 200) {
    Write-Host "   OK!" -ForegroundColor Green
    $script:CSToolReport+="+ SUCCESS: Real-time service        https://$varCC_Name-realtime.centrastage.net"
} else {
    Write-host "Failed" -ForegroundColor Red
    $script:CSToolReport+="! FAILURE: Real-time service        https://$varCC_Name-realtime.centrastage.net"
}

#=============================================== new line ===============================================

#component repo/s
write-host "     Components (Local/Offsite) " -nonewline
if (makeHTTPRequest "https://cpt$varCC_NameAlt.centrastage.net" 403) {
    $varCPTSuccess++
    $script:CSToolReport+="+ SUCCESS: Components (Local)       https://cpt$varCC_NameAlt.centrastage.net"
} else {
    $script:CSToolReport+="! FAILURE: Components (Local)       https://cpt$varCC_NameAlt.centrastage.net"
}

if (makeHTTPRequest "https://cpt$varCC_NameAlt.centrastage.net.s3.amazonaws.com" 403) {
    $varCPTSuccess++
    $script:CSToolReport+="+ SUCCESS: Components (Offsite)     https://cpt$varCC_NameAlt.centrastage.net.s3.amazonaws.com"
} else {
    $script:CSToolReport+="! FAILURE: Components (Offsite)     https://cpt$varCC_NameAlt.centrastage.net.s3.amazonaws.com"
}

if ($varCPTSuccess -ne 2) {
    Write-host " Failed" -ForegroundColor Red -NoNewline
} else {
    Write-Host "2/2 OK!" -ForegroundColor Green -NoNewline
}

write-host "   ||   " -foregroundcolor DarkGray -nonewline

#agent service
write-host "Agent Service               " -nonewline
if (makeHTTPRequest "https://$varCC_Name-agent.centrastage.net/cs/version" 200) {
    Write-Host "   OK!" -ForegroundColor Green
    $script:CSToolReport+="+ SUCCESS: Agent service            https://$varCC_Name-agent.centrastage.net"
} else {
    Write-host "Failed" -ForegroundColor Red
    $script:CSToolReport+="! FAILURE: Agent service            https://$varCC_Name-agent.centrastage.net"
}

#=============================================== new line ===============================================

#agent notifications
write-host "     Agent Notifications         " -NoNewline
if (makeHTTPRequest "https://$varCC_Name-agent-notifications.centrastage.net" 401) {
    Write-Host "   OK!" -ForegroundColor Green -NoNewline
    $script:CSToolReport+="+ SUCCESS: Agent Notifications      https://$varCC_Name-agent-notifications.centrastage.net"
} else {
    Write-host "Failed" -ForegroundColor Red -NoNewline
    $script:CSToolReport+="! FAILURE: Agent Notifications      https://$varCC_Name-agent-notifications.centrastage.net"
}

write-host "   ||   " -foregroundcolor DarkGray -nonewline

#agent communications
write-host "Agent Communications        " -nonewline
if (makeHTTPRequest "https://$varCC_Name-agent-comms.centrastage.net" 401) {
    Write-Host "   OK!" -ForegroundColor Green
    $script:CSToolReport+="+ SUCCESS: Agent Communications     https://$varCC_Name-agent-comms.centrastage.net"
} else {
    Write-host "Failed" -ForegroundColor Red
    $script:CSToolReport+="! FAILURE: Agent Communications     https://$varCC_Name-agent-comms.centrastage.net"
}

#=============================================== new line ===============================================

#agent gateway
[int]$varSuccess=0
write-host "     Agent Gateway & Features    " -NoNewline #stop adding subdomains, you're killing me
if (makeHTTPRequest "https://agent-gateway.$varCC_Name.rmm.datto.com" 403) {
    $varSuccess+=1
    $script:CSToolReport+="+ SUCCESS: Agent Gateway            https://agent-gateway.$varCC_Name.rmm.datto.com"
} else {
    $script:CSToolReport+="! FAILURE: Agent Gateway            https://agent-gateway.$varCC_Name.rmm.datto.com"
}

if (makeHTTPRequest "https://features.$varCC_Name.rmm.datto.com" 404) {
    $varSuccess+=2
    $script:CSToolReport+="+ SUCCESS: Agent Feature-flags      https://features.$varCC_Name.rmm.datto.com"
} else {
    $script:CSToolReport+="! FAILURE: Agent Feature-flags      https://features.$varCC_Name.rmm.datto.com"
}

if ($varSuccess -eq 3) {
    Write-Host "   OK!" -ForegroundColor Green -NoNewline
} else {
    Write-Host "Issues" -ForegroundColor Red -NoNewline
}

write-host "   ||   " -foregroundcolor DarkGray -nonewline

#------------------------------------------------ sub-section: windows update checks

$script:CSToolReport+=""
$script:CSToolReport+=": Connectivity Scan results for Windows Update services:"
write-host "Windows Update Sites     " -nonewline
("https://windowsupdate.microsoft.com","http://download.windowsupdate.com","https://download.microsoft.com","http://ctldl.windowsupdate.com","https://update.microsoft.com") | % {
    if (makeHTTPRequest "$_" 200) {
        $script:CSToolReport+="+ SUCCESS: Windows Update Services  $_"
        $varWUpd++
    } else {
        $script:CSToolReport+="! FAILURE: Windows Update Services  $_"
    }
}

if (makeHTTPRequest "http://dl.delivery.mp.microsoft.com" 403) {
    $script:CSToolReport+="+ SUCCESS: Windows Update Services  http://dl.delivery.mp.microsoft.com"
    $varWUpd++
} else {
    $script:CSToolReport+="! FAILURE: Windows Update Services  http://dl.delivery.mp.microsoft.com"
}

("https://wdcp.microsoft.com","https://wdcpalt.microsoft.com") | % {
    if (makeHTTPRequest "$_" 503) {
        $script:CSToolReport+="+ SUCCESS: Windows Update Services  $_"
        $varWUpd++
    } else {
        $script:CSToolReport+="! FAILURE: Windows Update Services  $_"
    }
}

if ($varWUpd -ne 8) {
    write-host "      $varWUpd/8" -ForegroundColor Red
    $script:CSToolReport+=": Windows Update sites can be unreliable. Treat a couple of failures as an anomaly."
} else {
    write-host "8/8 OK!"        -ForegroundColor Green
}

#=============================================== new line ===============================================

$script:CSToolReport+=""
$script:CSToolReport+=": Connectivity Scan results for Datto RMM IP-based services:"

#gather platform IP addresses from DNS
write-host "     Platform IPs" -NoNewline

#first, compile a list of IPs for the platform at-hand to check later
$arrPlatIPs=@()
try {
    $varPlatIPCheck=[System.Net.Dns]::GetHostAddresses("$varCC_Name-ips.centrastage.net")
    if ($(($varPlatIPCheck|measure-object).count) -le 0) {
        throw
    } else {
        $varPlatIPCheck | % {
            $arrPlatIPs+=$($_.IPAddressToString)
        }
    }
} catch {
    write-host "             No Access" -ForegroundColor Red -NoNewline
    $script:CSToolReport+="! FAILURE: Platform IP list         $varCC_Name-ips.centrastage.net"
    $script:CSToolReport+="           The tool will be unable to test Platform IPs as it could not enumerate any."
}

#now check through our list
if (($arrPlatIPs|measure-object).count -ge 1) {
    processIPList $arrPlatIPs "     Platform IPs              " 10 "Platform     "
}

write-host "   ||   " -foregroundcolor DarkGray -nonewline

#VERSION: cagService
write-host "Service version    " -nonewline
try {
    [xml]$varCagSvcXML=(New-Object System.Net.WebClient).DownloadString("https://update$varCC_NameAlt.centrastage.net/cagupdate/UpdateState.xml")
    Write-Host "OK:       $($varCagSvcXML.UpdateStatus.CurrentVersion)" -ForegroundColor Yellow
    $varCagSvc = $varCagSvcXML.UpdateStatus.CurrentVersion
} catch {
    Write-host "    No Access" -foregroundcolor Red
}

#=============================================== new line ===============================================

#tunnel servers :: as before, but with an additional compilation step
write-host "     Tunnel Server IPs" -NoNewline
$arrTunIPs=@()
try {
    $varTunIPCheck=[System.Net.Dns]::GetHostAddresses("tunnel-ips.centrastage.net")
    if ($(($varTunIPCheck|measure-object).count) -le 0) {
        #do nothing, we'll verify later
    } else {
        $varTunIPCheck | % {
            $arrTunIPs+=$($_.IPAddressToString)
        }
    }
} catch {
    $CSTunIPFail=$true
}

#now check through our list
if (($arrTunIPs|measure-object).count -ge 1) {
    processIPList $arrTunIPs "     Tunnel Server IPs       " 1 "Tunnel Server"
} else {
    $CSTunIPFail=$true
}

if ($CSTunIPFail) {
    write-host "        No Access" -ForegroundColor Red -NoNewline
    $script:CSToolReport+="! FAILURE: Platform IP list         tunnel-ips.centrastage.net"
    $script:CSToolReport+="           The tool will be unable to test Tunnel Server IPs as it could not enumerate any."
}

write-host "   ||   " -foregroundcolor DarkGray -nonewline

#aemagent version
write-host "AEMAgent version   " -nonewline
try {
$varAEMAjson = (New-Object System.Net.WebClient).DownloadString("https://update$varCC_NameAlt.centrastage.net/cagupdate/aem-agent/version.json")
$varAEMAver=$varAEMAjson.split('"')[3]
    write-host "OK: $varAEMAVer" -ForegroundColor Yellow
} catch {
    Write-host "    No Access" -foregroundcolor Red
}

#=============================================== new line ===============================================

write-host `r
write-host "        Expect ~10 IP check failures." -ForegroundColor Green -NoNewline
write-host " Version checks are testing connectivity." -ForegroundColor Cyan
write-host `r

write-host "Datto RMM Platform connectivity checks complete." -ForegroundColor Cyan
write-host "Press " -NoNewline; write-host "[ENTER]" -nonewline -ForegroundColor Red; write-host " to advance to Page 2, where Endpoint checks are conducted." -NoNewline
$HOST.UI.RawUI.FlushInputBuffer()
$choiceInput = read-host
switch ($choiceInput) {
    default {
        clear-host
    }
}

# ==================================================================== PAGE TWO ===================================================================

#------------------------------------------------ sub-section: preamble

write-host "Page 2: Endpoint Health"
if ($CSAdmin) {
    write-host "Tool is being run as an Administrator    " -ForegroundColor Cyan
} else {
    write-host "Tool is not being run as an Administrator" -ForegroundColor Red
}
write-Host "============================="
write-host "                               -== Endpoint Checks ==-" -foregroundcolor Green
write-host `r

#system info
write-host "     Device Detail: " -NoNewline
write-host "`"$env:Computername`" " -NoNewline -ForegroundColor Yellow
write-host "Build $varWinver / $varCaption "

#------------------------------------------------ sub-section: SKU check (july 2024)

#write log output
$script:CSToolReport+="=================================="
$script:CSToolReport+= ""
$script:CSToolReport+="= Endpoint and Agent Health Check Results:"

#check
write-host "            OS SKU: " -NoNewline; write-host "$varSKU" -NoNewline -ForegroundColor Yellow; write-host " / " -NoNewline

if (((7..10),(12..15),(17..25),(29..46),(50..56),(59..64),72,76,77,79,80,95,96,109,110,120,(143..148),159,160,168,169 | write-output) -contains $varSKU) {
    write-host "Device is a Server" -ForegroundColor Cyan
    $script:CSToolReport += ": Device is a Server (SKU $varSKU)."
    $varServer=$true
} elseif ((2,3,5,11,26,47,66,68,(98..101) | write-output) -contains $varSKU) {
    write-host "Device is running a Home version of Windows" -ForegroundColor Red
    $script:CSToolReport += "! WARNING: Device is running a Home version of Windows (SKU $varSKU)."
    $script:CSToolReport += "           This SKU is not officially supported or tested against."
} else {
    write-host "Device is a Workstation" -ForegroundColor Cyan
    $script:CSToolReport += ": Device is a Workstation (SKU $varSKU)."
}

#------------------------------------------------ sub-section: uptime calculation

try {
    $varLastBootTime=[Management.ManagementDateTimeConverter]::ToDateTime($varLastBootWMI) | New-TimeSpan
    if (($varLastBootTime.Days -as [String]).Length -eq 3) {
        $varBootString='{0}D ' -f $varLastBootTime.Days
    } elseif (($varLastBootTime.Days -as [String]).Length -eq 2) {
        $varBootString=' {0}D ' -f $varLastBootTime.Days
    } else {
        $varBootString=' 0{0}D ' -f $varLastBootTime.Days
    }

    if (($varLastBootTime.Hours -as [String]).Length -eq 1) {
        $varBootString+='0{0}H ' -f $varLastBootTime.Hours
    } else {
        $varBootString+='{0}H ' -f $varLastBootTime.Hours
    }

    if (($varLastBootTime.Minutes -as [String]).Length -eq 1) {
        $varBootString+='0{0}M ' -f $varLastBootTime.Minutes
    } else {
        $varBootString+='{0}M ' -f $varLastBootTime.Minutes
    }
} catch {
    $varWMIIssues="Significant"
    $varBootString="WMI Error"
}

write-host "     System Uptime:" -NoNewline
write-host $varBootString -ForegroundColor Yellow

write-host "`r"

$script:CSToolReport += ": System Uptime: $varBootString"

#------------------------------------------------ sub-section: AEMAgent

#AEMAgent check (stalled/issues/outdated/offline)
write-host "     AEMAgent State           " -NoNewline

if ($varOnDemand -eq 1) {
    #startup issues :: 5779805
    try {
        if (((get-date) - $((get-item "$env:PROGRAMDATA\CentraStage\AEMAgent\DataLog\aemagent.log").LastWriteTime)) -gt $(new-timespan -minutes 30)) {
            $CSAAIssues="  Stalled"
            $script:CSToolReport+= "! FAILURE: AEMAgent appears to have stopped logging data."
            $script:CSToolReport+= "           Please consider reinstalling the Agent."
        } else {
            $script:CSToolReport+= "+ SUCCESS: AEMAgent is able to start up successfully."
        }
    } catch {
            $CSAAIssues="  Absent"
            $script:CSToolReport+= "! FAILURE: AEMAgent does not appear to be producing logging data."
            $script:CSToolReport+= "           It is possible AEMAgent has not been despatched onto this device."
    }

    #HTTP OK
    if ($CSAAIssues) {
        $script:CSToolReport+= " Skipping HTTP check as the Monitoring Agent has not started properly."
    } else {
        #make a log instalment of just the active session and analyse it for the correct HTTP OKs
        try {
            $CSCurrentLog=$CSDataLog | Select-Object -Skip ((($CSDataLog | Select-String -Pattern 'SYSTEM START')[-1].LineNumber) - 1)
        } catch {
            $CSCurrentLog=$CSDataLog
        }

        $varLog50=($CSCurrentLog | select -Last 50 -ErrorAction SilentlyContinue) -split [System.Environment]::NewLine

        if (($CSCurrentLog | ? {$_ -match "`"HttpStatusCode`": 200"} | Measure-Object).count -lt 3) {
            if (!$CSAAIssues) {$CSAAIssues="Restarted"}
            Stop-Process -Name AEMAgent -Force -ErrorAction SilentlyContinue 2>&1>$null
            start-sleep -seconds 1
            $count=0
            $script:CSToolReport+= "! FAILURE: AEMAgent appears to be having trouble sustaining a connection. (Fewer HTTP 200s than expected.)"
            $script:CSToolReport+= "           The AEMAgent Process has been restarted. Please re-run this test in two minutes and contact support if issues persist."
            while (!(get-process AEMAgent -ErrorAction SilentlyContinue)) {
                $count++
                $varRuntime=60-$count
                write-host "     Wait ($varRuntime) " -ForegroundColor DarkGray
                [Console]::SetCursorPosition(30,8)
                if ($count -eq 60) {
                    $CSAAIssues="   Failed"
                    $script:CSToolReport+= "! FAILURE: The AEMAgent Process could not be restarted gracefully. Consider re-installing."
                    break
                }
                start-sleep -Seconds 1
            }
        } else {
            $script:CSToolReport+= "+ SUCCESS: AEMAgent appears to be communicating with the platform. Additional tests will be performed later."
        }
    }

    #is it the latest version?
    $CSAAVerLocal=((($CSDataLog | Select-Object -Last 10 | select-string -Pattern '^[0-9]' | select-object -last 1) -as [string]) -split ("\|"))[0]
    if (!$CSAAVerLocal) {
        $CSAAIssues="   Absent"
        $script:CSToolReport+= "! FAILURE: AEMAgent does not appear to be running."
        $script:CSToolReport+= "  Ensure CagService has proper connectivity to the platform in order to download AEMAgent."
    } elseif ($CSAAVerLocal -ne $varAEMAVer) {
        #version mismatch
        if (!$CSAAIssues) {$CSAAIssues=" Outdated"}
        $script:CSToolReport+= "! FAILURE: AEMAgent is out of date (Latest: $varAEMAVer/Local: $CSAAVerLocal)."
        $script:CSToolReport+= "           This might be because the device cannot run .NET 6.0. Ensure the latest VC++ Redist is installed."
    } else {
        $script:CSToolReport+= "+ SUCCESS: AEMAgent is up-to-date (Version $varAEMAVer)."
    }

    #is it running?
    if ((get-process AEMAgent -ea 0 | Measure-Object).count -lt 1) {
        $script:CSToolReport+= "! FAILURE: AEMAgent is not running. It may not be installed."
        $script:CSToolReport+= "  If subsequent checks indicate connection issues, please ensure CagService is able to connect to download AEMAgent."
        if (!$CSAAIssues) {$CSAAIssues="  Offline"}
    } else {
        $script:CSToolReport+= "+ SUCCESS: AEMAgent is running and monitoring."
    }

    #is it blocked?
    if (($CSCurrentLog | where-object {$_ -match '(Key platform denied|forbidden|human)'} | Measure-Object).count -ge 1) {
        $CSAAIssues=" Blocked?"
        $script:CSToolReport+= "! WARNING: The platform may be rejecting the device's Agent key. Check the device over and ensure it hasn't been tampered with."
        $script:CSToolReport+= "           If it hasn't been already, re-approve the device from the New UI in the Devices section."
    }

    #is it in the correct location i
    $CSReg=(gp "HKLM:\Software\CentraStage" -ea 0).AgentFolderLocation
    if ($CSReg) {
        if ($CSProgData) {
            if ($CSReg -ne $CSProgData) {
                $CSAAIssues=" Registry"
                $script:CSToolReport+= "! WARNING: HKLM:\Software\CentraStage!AgentFolderLocation and actual AEMAgent running locations disagree."
                $script:CSToolReport+= "  Please contact Support. A reinstallation is recommended."
            }
        }
    } else {
        $CSAAIssues=" Registry"
        $script:CSToolReport+= "! WARNING: The Registry value HKLM:\Software\CentraStage!AgentFolderLocation is absent. Reinstall recommended."
    }

    #is it in the correct location ii
    if (($CSProgData | split-path -leaf) -notmatch '^CentraStage$') {
        $CSAAIssues=" Location"
        $script:CSToolReport+= "! WARNING: Agent folder install location is not ProgramData\CentraStage."
        $script:CSToolReport+= "  Please contact Support. A reinstallation is recommended."
    }

    #event log issues?
    if (($CSCurrentLog | where-object {$_ -match 'The event log file is corrupted'} | Measure-Object).count -ge 1) {
        $CSAAIssues="Event Log"
        $script:CSToolReport+= "! WARNING: The Agent is reporting that the device's Event Log is corrupted. Please triage."
    }

    if (!$CSAAIssues) {
        write-host "      OK!" -ForegroundColor Green -NoNewline
    } else {
        write-host "$CSAAIssues" -ForegroundColor Red -NoNewline
    }
} elseif ($varOnDemand -eq 2) {
    write-host " OnDemand" -ForegroundColor Yellow -NoNewline
    $script:CSToolReport+= ": UNKNOWN: AEMAgent health checks skipped; the Agent is running as OnDemand, so AEMAgent is not running."
} else {
    write-host " No Admin" -ForegroundColor Red -NoNewline
    $script:CSToolReport+= ": UNKNOWN: AEMAgent health checks skipped; as the script was not run as Administrator, the OnDemand check could not run."
}

write-host "   ||   " -foregroundcolor DarkGray -nonewline

#------------------------------------------------ sub-section: CagService

#is it the latest version
$CSAgentVer=(([System.Diagnostics.FileVersionInfo]::GetVersionInfo("$varProg32\CentraStage\Core.dll").FileVersion).split(".")[3])
if ($varCagSvc) {
    if ($varCagSvc -eq $CSAgentVer) {
        $script:CSToolReport+= "+ SUCCESS: CagService Agent Service is up-to-date (Version $CSAgentVer)."
    } else {
        $CSCSIssues="       Outdated"
        $script:CSToolReport+= "! FAILURE: CagService is out of date."
        $script:CSToolReport+= "           Latest version is $varCagSvc. Version on Endpoint is $CSAgentVer`."
    }
} else {
    $CSCSIssues="         Issues"
    $script:CSToolReport+= "! FAILURE: Connection issues prevented the tool from finding out whether CagService is up-to-date."
}

#is it running
write-host "CagService State   " -NoNewline
if ((get-process CagService -ea 0 | measure-object).count -lt 1) {
    if (!$CSCSIssues) {$CSCSIssues="        Offline"}
    $script:CSToolReport+= "! FAILURE: CagService Agent Service is not running."
} else {
    $script:CSToolReport+= "+ SUCCESS: CagService Agent Service is running. "
}

#is gui.exe the same version as core.dll?
if ($varCagSvc -eq $((([System.Diagnostics.FileVersionInfo]::GetVersionInfo("$varProg32\CentraStage\gui.exe").FileVersion).split(".")[3]))) {
    $script:CSToolReport+= "+ SUCCESS: GUI.exe and Core.dll are the same version."
} else {
    $CSCSIssues="       Outdated"
    $script:CSToolReport+= "! FAILURE: GUI.exe and Core.dll are not the same version."
}

#is the device overprovisioned? (this will override any other issue)
$CSLog=get-content "$varProg32\CentraStage\log.txt" -ea 0
if ($CSLog | Select-String -Pattern 'error code 429' -Quiet) {
    if (!($CSLog | Select-String -Pattern 'Response is Http - 200' -Quiet)) {
        $CSCSIssues="Overprovisioned"
        $script:CSToolReport+= "! FAILURE: The Agent cannot contact the platform because the account has passed its device limit."
        $script:CSToolReport+= "           Please reduce the amount of devices in your account or contact your account manager."
    }
}

#dotnet misconfiguration (override)
if (([IntPtr]::size) -eq 8) {
    if (test-path "$env:systemRoot\Microsoft.NET\Framework64\v2.0.50727\ldr64.exe" -ea 0) {
        if (((cmd /c "$env:systemRoot\Microsoft.NET\Framework64\v2.0.50727\ldr64.exe query" | select-string '0x0') -as [string]).split('x')[1] -eq '00000000') {
            $CSCSIssues="Framework Issue"
            $script:CSToolReport+="! FAILURE: This device has been configured to use the 32-bit (Windows-on-Windows) version of the .NET Framework."
            $script:CSToolReport+=""
            $script:CSToolReport+="  Some applications, like CagService, are configured to use the device's native architecture, but a setting"
            $script:CSToolReport+="  exists for .NET to use the 32-bit version in all situations. On this device, that setting has been enabled."
            $script:CSToolReport+="  This override setting is incompatible with the Datto RMM Agent as it is known to cause multiple issues."
            $script:CSToolReport+=""
            $script:CSToolReport+="  As this is a localised issue, Support cannot assist with it; most likely this setting was either configured"
            $script:CSToolReport+="  deliberately by the System Administrator or unilaterally during an unrelated software installation."
            $script:CSToolReport+="  (The default behaviour of the .NET Framework on 64-bit systems is to use 64-bit wherever possible.)"
            $script:CSToolReport+="  In either case, changing it back to the recommended system default could cause unforeseen issues, so the"
            $script:CSToolReport+="  command given below should be run on this endpoint only after careful consideration."
            $script:CSToolReport+=""
            $script:CSToolReport+="  The following Batch command will set the .NET Framework back to its default architecture setting:"
            $script:CSToolReport+="  C:\Windows\Microsoft.NET\Framework64\v2.0.50727\ldr64.exe set64"
            $script:CSToolReport+=""
            $script:CSToolReport+="  This will re-configure the Framework to use 64-bit where possible. This will fix the Datto RMM Agent, but"
            $script:CSToolReport+="  it may break whatever else needed things configured that way in the first place. Kaseya cannot be held"
            $script:CSToolReport+="  responsible for issues that arise as a result of changing this setting back to its system default."
        }
    }
}

if (!$CSCSIssues) {
    write-host "            OK!" -ForegroundColor Green
} else {
    write-host "$CSCSIssues" -ForegroundColor Red
}

#=============================================== new line ===============================================

#------------------------------------------------ sub-section: smaller checks

#monitor health: errors appearing in AEMAgentLog
write-host "     Monitor Health            " -nonewline

$arrError=@{
   'Exception'           ='Connection exception; a connection was attempted but failed without receiving a proper response.'
   'RE-TRY'              ='Connection retry attempt; a connection failure spawned a subsequent reconnection attempt.'
   'HttpStatusCode": 403'='HTTP 403: Unauthorised. This can indicate platform-side device rejection. Check the web portal for device approvals.'
}

$arrError.GetEnumerator() | % {
    $currentName=$_.Name
    $currentValue=$_.Value
    if ((($varLog50 | ? {$_ -match $currentName} | measure-object).count) -gt 4) {
        $CSMonHealth="  Issues"
        $script:CSToolReport+= "! FAILURE: $(($varLog50 | ? {$_ -match $currentName} | Measure-Object).count) recent errors matching `'$currentName`' detected in AEMAgent log file. "
        $script:CSToolReport+= "           Error detail: $currentValue"
    }
}

if (!$CSMonHealth) {
    write-host "     OK!" -ForegroundColor Green -NoNewline
    $script:CSToolReport+= "+ SUCCESS: No connection issues were identified in the AEMAgent monitoring log. "
} else {
    write-host "$CSMonHealth" -ForegroundColor Red -NoNewline
}

write-host "   ||   " -foregroundcolor DarkGray -nonewline

#duplicate nlog.dll check
write-host "NLog.dll Clashes          " -nonewline
$CSPathTest = @(Get-ChildItem -Path "C:\Windows\Microsoft.NET\assembly" -Recurse | Where-Object {$_.Name -match "^nlog\.dll"})
if ($CSPathTest.length -gt 0) {
        $CSDupeFound = $true
        $script:CSToolReport+= "! FAILURE: NLog.dll was found in the Endpoint`'s GAC, which can cause the Agent not to start."
        $script:CSToolReport+= "           If the Agent does not start, remove NLog.dll from the C:\Windows\Microsoft.NET\Assembly location."
        $script:CSToolReport+= "           If the Agent is functioning normally, this can be disregarded."
}
if (!$CSDupeFound) {
    write-host " 0 Found" -ForegroundColor Green
    $script:CSToolReport+= "+ SUCCESS: No NLog.dll clashes were found on Endpoint."
} else {
    write-host "Detected" -foregroundcolor Red
}

#=============================================== new line ===============================================

#------------------------------------------------ sub-section: dotnet checks for 10.8+

write-host "     System Compatibility   " -nonewline
#if it's less than ten/some server variants, throw it in the bin
if ($varWinver -lt 10240) {
    switch -regex ($varWinver) {
        '^2' {
            write-host "   Obsolete" -foregroundcolor Red -NoNewline
            $script:CSToolReport+="! FAILURE: The Agent is no longer supported on Windows XP. Please replace the device."
        } '^3' {
            write-host "   Obsolete" -foregroundcolor Red -NoNewline
            $script:CSToolReport+="! FAILURE: The Agent is no longer supported on Windows XP/Server 2003. Please replace the device."
        } '^6' {
            write-host "   Obsolete" -foregroundcolor Red -NoNewline
            if ($varServer) {
                $script:CSToolReport+="! FAILURE: The Agent is no longer supported on Windows Server 2008 (or derivatives). Please replace the device."
            } else {
                $script:CSToolReport+="! FAILURE: The Agent is no longer supported on Windows Vista. Please replace the device."
            }
        } '^7' {
            write-host "   Obsolete" -foregroundcolor Red -NoNewline
            if ($varServer) {
                $script:CSToolReport+="! FAILURE: The Agent is no longer supported on Windows Server 2008 R2 (or derivatives). Please replace the device."
            } else {
                $script:CSToolReport+="! FAILURE: The Agent is no longer supported on Windows 7 (or derivatives). Please replace the device."
            }
        } '^9' {
            if ($varServer) {
                if ($([int][double]::Parse((Get-Date -UFormat %s))) -gt 1791590400) {
                    #10 october 2026
                    write-host "   Obsolete" -foregroundcolor Red -NoNewline
                    $script:CSToolReport+="! FAILURE: Windows Server 2012/R2 became EOL in October 2026. This OS is no longer maintained and represents a security risk."
                } else {
                    write-host "    Caution" -foregroundcolor Yellow -NoNewline
                    $script:CSToolReport+="! CAUTION: Windows Server 2012/R2 became EOL in October 2023, with extended support purchasable until 2026."
                }
            } else {
                $script:CSToolReport+="! FAILURE: Windows 8/8.1 support ran out in January 2023. This OS is no longer maintained and represents a security risk."
            }
        } default {
            write-host "   Obsolete" -foregroundcolor Red -NoNewline
            $script:CSToolReport+="! FAILURE: Versions of Windows earlier than 10 are no longer maintained by Microsoft and represent a security risk."
        }
    }
} else {
    #running 10+/server 2016+; check for VC++
    if (!(getGUID2 'Visual C\+\+ 2015-20')) {
        write-host "Update VC++" -foregroundcolor Red -NoNewline
        $script:CSToolReport+="! FAILURE: AEMAgent requires the latest Visual C++ Redistributable package to run."
        $script:CSToolReport+="           Ensure the packages for both architectures are installed."
        $script:CSToolReport+="           If these packages are already installed and the Agent is functioning, there may be an issue"
        $script:CSToolReport+="           with this device's Registry; please fully scrutinise this tool's log output for indicators."
    } else {
        if ($varServer) {
            $varKernelMin=14393 #server 2016
        } else {
            $varKernelMin=19045 #w10 22h2
        }

        if ($varWinVer -lt $varKernelMin) {
            write-host "   Obsolete" -foregroundcolor Red -NoNewline
            $script:CSToolReport+="! FAILURE: Windows 10 pre-22H2 support has expired. This OS is no longer maintained and represents a security risk."
        } else {
            write-host "        OK!" -foregroundcolor Green -NoNewline
            $script:CSToolReport+= "+ SUCCESS: This device's operating system is still maintained by Microsoft and will support Datto RMM."
        }
    }
}

write-host "   ||   " -foregroundcolor DarkGray -nonewline
    
#FIPS-compliance check
write-host "Windows 'FIPS Mode'       " -nonewline
if ((Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Lsa\FIPSAlgorithmPolicy" -ea 0).Enabled -eq 1) {
    $varFIPS++
}
if ((Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Lsa\FIPSAlgorithmPolicy" -ea 0).MDMEnabled -eq 1) {
    $varFIPS++
}

if ($varFIPS) {
    write-host " Engaged" -ForegroundColor Red
    $script:CSToolReport+= "! FAILURE: Endpoint enforces Windows 'FIPS mode'. This setting does not make the device any safer; rather,"
    $script:CSToolReport+= "  it can actually hinder security as it prevents newer cryptographic cyphers, like those used by Datto RMM,"
    $script:CSToolReport+= "  from functioning. Regardless of product FIPS support, Datto RMM does not support 'FIPS mode' and never"
    $script:CSToolReport+= "  will, nor will any major RMM software product; it must be disabled for the software to work properly."
    $script:CSToolReport+= "  More info: https://preview.tinyurl.com/3a9xs3b8 (Web Archive link of archived Microsoft documentation)"
} else {
    write-host "Disabled" -foregroundcolor green
    $script:CSToolReport+= "+ SUCCESS: FIPS-Compliance, which can cause connectivity issues, is not mandated on this device."
}

#=============================================== new line ===============================================

#system drive: at least 1GB free
write-host "     System Drive Space       " -nonewline

try {
    if ([math]::Round((get-WmiObject win32_logicaldisk -Filter "DeviceID='$env:SystemDrive'" -ea stop).FreeSpace /1GB) -lt 1) {
        write-host "Need >1GB" -ForegroundColor Red -nonewline
        $script:CSToolReport+= "! FAILURE: Endpoint requires at least 1GB of free space on the System Drive to function properly."
    } else {
        write-host ">1GB Free" -ForegroundColor Green -NoNewline
        $script:CSToolReport+= "+ SUCCESS: Endpoint has at least 1GB of free space on the System Drive."
    }
} catch {
    write-host "WMI Error" -ForegroundColor Red -nonewline
    $script:CSToolReport+= "! FAILURE: Unable to ascertain disk space; WMI issues suspected"
}

write-host "   ||   " -foregroundcolor DarkGray -nonewline

#event logs
write-host "RMM Service Event Logs    " -nonewline
$CSEventLogData = Get-EventLog -LogName System -Source 'Service Control Manager' -After (Get-Date).AddDays(-7)| Where-Object -FilterScript {($_.Message -match 'CentraStage') -and ($_.EventID -notmatch '^(7036|7045)$')} | Select-Object -Property EventID, Message, TimeWritten | Group-Object -Property Message
if (($CSEventLogData | measure-object).count -ge 1) {
        $script:CSToolReport+=""
        $script:CSToolReport+="= Summary of CagService-related problem events from last 7 days of Event Log:"
    if ((get-host).version.Major -ge 5) {
        #powershell 5 version
        foreach ($Event in $CSEventLogData) {
            if ($event) {
                $CSLogsPresent++
                $script:CSToolReport += "! FAILURE: Noteworthy CagService Event Log group discovered:"
                $script:CSToolReport += "Event group with IDs [$($event.Group.eventID)] logged at [$($event.group.TimeWritten)]"
                $script:CSToolReport += ": : : : : : : : : : : : : : : : : : :"
                $script:CSToolReport += $event.Group.message
                $script:CSToolReport += "`r`n- - - - - - - - - - - - - - - - - - -"
            }
        }
    } else {
        #powershell 2-4 version
        if ($CSEventLogData) {
            $CSLogsPresent++
            $script:CSToolReport += "! FAILURE: Noteworthy CagService Event Log entries noted in attached CSV."
            if (!$CSResultDirectory) {
                makeFolder
            }
            $CSEventLogData | Export-CSV -path "$CSResultDirectory\AHC-$env:computername-EventLog-$(EpochTime).csv"
        }
    }
}

if (!$CSLogsPresent) {
    write-host "0 Issues" -ForegroundColor Green
    $script:CSToolReport += "`+ SUCCESS: No noteworthy RMM Agent Service-related Event Logs were discovered."
} else {
    $script:CSToolReport += "`: No further Event Log entries of note were discovered."
    $script:CSToolReport+=""
    write-host "  Issues" -ForegroundColor Red
}

#=============================================== new line ===============================================

#certificate check :: september 2025
write-host "     SSL Configuration         " -NoNewline

[hashtable]$arrCerts = @{
    'CN=Amazon Root CA 1, O=Amazon, C=US'="8d a7 f9 65 ec 5e fc 37 91 0f 1c 6e 59 fd c1 cc 6a 6e de 16"
    'CN=Amazon Root CA 2, O=Amazon, C=US'="5a 8c ef 45 d7 a6 98 59 76 7a 8c 8b 44 96 b5 78 cf 47 4b 1a"
    'CN=Amazon Root CA 3, O=Amazon, C=US'="0d 44 dd 8c 3c 8c 1a 1a 58 75 64 81 e9 0f 2e 2a ff b3 d2 6e"
    'CN=Amazon Root CA 4, O=Amazon, C=US'="f6 10 84 07 d6 f8 bb 67 98 0c c2 e2 44 c2 eb ae 1c ef 63 be"
    'CN=Starfield Services Root Certificate Authority - G2, O=Starfield Technologies, Inc., L=Scottsdale, S=Arizona, C=US'='92 5a 8f 8d 2c 6d 04 e0 66 5f 59 6a ff 22 d8 63 e8 25 6f 3f'
    'CN=DigiCert Global Root G2, OU=www.digicert.com, O=DigiCert Inc, C=US'="df 3c 24 f9 bf d6 66 76 1b 26 80 73 fe 06 d1 cc 8d 4f 82 a4"
    'CN=DigiCert Trusted Root G4, OU=www.digicert.com, O=DigiCert Inc, C=US'="dd fb 16 cd 49 31 c9 73 a2 03 7d 3f c8 3a 4d 7d 77 5d 05 e4"
}

#5813800
$CSInstalledCerts=certutil -store root
$CSInstalledCerts+=certutil -store authroot

$arrCerts.GetEnumerator() | % {
    $name=$_.Name
    $thumbprint=$_.value
    ($thumbprint,$($thumbprint -replace ' ')) | % {
        try {
            if ($CSInstalledCerts.length -gt 10) {
                if (($CSInstalledCerts | select-string "$_" -Context 8,2) -as [string] | select-string $name -quiet) {
                    if ($name -match 'DigiCert') {
                        $CSCertPassDigiCert++
                    }
		            $CSCertPass++
                }
            }
        } catch {
            #do nothing
        }
    }
}

if (!$CSCertPass -and $CSCertPassDigiCert) {
    write-host "  Absent" -ForegroundColor Red -NoNewline
    $script:CSToolReport+="! FAILURE: The Amazon Root CA certificate necessary to access Datto RMM online have not been installed."
    $script:CSToolReport+="           These will need to be installed in order to access the Datto RMM Web Portal."
    $script:CSToolReport+="           Download Amazon Root CA 1 certificate at: https://www.amazontrust.com/repository/ and install."
    $script:CSToolReport+="           Ensure certificates are installed at the machine-level and NOT the user-level."
} elseif ($CSCertPass -and !$CSCertPassDigiCert) {
    write-host "  Absent" -ForegroundColor Red -NoNewline
    $script:CSToolReport+="! FAILURE: The DigiCert Global Root G2 Certificate necessary for Agent connectivity is not installed."
    $script:CSToolReport+="           This will need to be installed in order to facilitate Agent-to-Platform connectivity."
    $script:CSToolReport+="           Download 'DigiCert Global Root G2' and 'DigiCert Trusted Root G4' from this site:"
    $script:CSToolReport+="           https://www.digicert.com/kb/digicert-root-certificates.htm"
    $script:CSToolReport+="           And install, ensuring certificates are installed at the machine-level and NOT the user-level."
} elseif (!$CSCertPass -and !$CSCertPassDigiCert) {
    write-host "  Absent" -ForegroundColor Red -NoNewline
    $script:CSToolReport+="! FAILURE: Neither the Amazon Root CA certificate nor the DigiCert Global Root G2 certificates are installed."
    $script:CSToolReport+="           This will prevent the Agent from connecting to the platform and the device from connecting to the portal."
    $script:CSToolReport+="           Download Amazon Root CA 1 certificate at: https://www.amazontrust.com/repository/ and install."
    $script:CSToolReport+="           Download 'DigiCert Global Root G2' at: https://www.digicert.com/kb/digicert-root-certificates.htm and install."
    $script:CSToolReport+="           Ensure certificates are installed at the machine-level and NOT the user-level."
} else {
    #since this check passed, perform the rest
    if ((gp "HKLM:\Software\Policies\Microsoft\SystemCertificates\ChainEngine\Config" -ea 0).options -eq 2) {
        write-host "  Adjust" -ForegroundColor Red -NoNewline
        $script:CSToolReport+="! FAILURE: Authority Information Access (AIA) is disabled or misconfigured on this device."
        $script:CSToolReport+="  This may inhibit the building of certificate chains critical to establishing safe connections."
        $script:CSToolReport+="  More information: https://learn.microsoft.com/en-us/windows-server/security/authority-information-access-retrieval"
    } else {
        #all good
        write-host "     OK!" -ForegroundColor GrEeN -NoNewline
        $script:CSToolReport+="+ SUCCESS: The relevant certificates to access Datto RMM online are installed."
        $script:CSToolReport+="           Authority Information Access (AIA) is configured properly on this device."
        $script:CSToolReport+="           This tool cannot check whether these certificates are actually enabled; in case of TLS issues, it may be"
        $script:CSToolReport+="           worth investigating whether the Amazon Root CA, Starfield, and DigiCert Global Root certificates on the"
        $script:CSToolReport+="           device have not had their capabilities malconfigured."
    }
}

write-host "   ||   " -foregroundcolor DarkGray -nonewline

#------------------------------------------------ sub-section: various agent file verification checks

write-host "Agent File Validation    " -nonewline
if (!$CSAdmin) {
    write-host " No Admin" -foregroundcolor Red
    $script:CSToolReport+=": UNKNOWN: Tool was unable to analyse Agent files for consistency because it was not run with Administrator-level access."
} else {

    #$arrXMLFiles used to be defined here, but it's been moved to load earlier so we can tell if the device is onDemand -- look for string "40HC89"
    if (($arrXMLFiles | measure-object).count -eq 0) {
        $script:CSXMLError++
        $script:CSToolReport += "! FAILURE: Could not locate Agent XML files. Is the Agent installed?"
    }

    $arrXMLFiles | ? {$_} | % {
        $CSXMLTest = New-Object System.Xml.XmlDocument
        try {
            $CSXMLTest.Load("$_")
            $script:CSToolReport += "+ SUCCESS: $_ passed XML verification."
        } catch [System.Xml.XmlException] {
            $script:CSXMLError++
            $script:CSToolReport += "! FAILURE: $_ is corrupt. Consider reinstalling the Agent."
        }
    }

    #check submittedpatches.json
    try {
        $CSPatchJSON = get-content "$env:ProgramData\CentraStage\SubmittedPatches.json" -ErrorAction Stop
		if ($CSPatchJSON.Substring(0,2) -notmatch "^\[\{$" -or $CSPatchJSON.Substring($CSPatchJSON.Length-2) -notmatch "^\}\]$") {
            $script:CSToolReport += "! FAILURE: $env:ProgramData\CentraStage\SubmittedPatches.json is corrupt."
		    $script:CSToolReport += "           Please delete this file or re-install the Agent."
            $script:CSXMLError++
        } else {
            $script:CSToolReport += "+ SUCCESS: $env:ProgramData\CentraStage\SubmittedPatches.json appears to be fine."
        }
    } catch {
        $script:CSToolReport += "+ SUCCESS: This device does not appear to be using Patch Management, making verification of patching JSON files unnecessary."
    }

    #check snmp.json
    if ((get-content "$env:ProgramData\CentraStage\snmp.json" -ea 0 | Select-Object -Last 1) -match '}') {
        $script:CSToolReport+="+ SUCCESS: The Agent's SNMP.json file did not contain any errors."
    } else {
        if (test-path "$env:ProgramData\CentraStage\") {
            if (test-path "$env:ProgramData\CentraStage\snmp.json" -ErrorAction SilentlyContinue) {
                Remove-Item "$env:ProgramData\CentraStage\snmp.json" -Force
            }
            set-content -Value '{
            "version": "1",
            "group": []
            }' -Path "$env:ProgramData\CentraStage\snmp.json" -Force
        } else {
            $script:CSToolReport+="! FAILURE: There is no CentraStage folder in ProgramData. Is the Agent installed?"
        }
        $script:CSToolReport+="! FAILURE: The Agent's SNMP.json file was absent or corrupt and has been remade from scratch."
        $script:CSXMLError++
    }

    #check software management
    if (Get-Childitem "$env:PROGRAMDATA\CentraStage\AEMAgent\Downloads" -Recurse | ? {$_.LastWriteTime -le (get-date).addDays(-1) }) {
        Get-Childitem "$env:PROGRAMDATA\CentraStage\AEMAgent\Downloads" -Recurse | ? {$_.LastWriteTime -le (get-date).addDays(-1) } | % {Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue}
        $script:CSToolReport+=":  NOTICE: Software Management downloads cleared. This can cause some transient download issues."
        $script:CSXMLError++
    } else {
        $script:CSToolReport+="+ SUCCESS: No need to adjust Software Management downloads folder."
    }

    #display results
    if ($script:CSXMLError) {
        write-host "Check Log" -ForegroundColor Red
    } else {
        write-host " 0 Issues" -foregroundcolor Green
    }
}

#=============================================== new line ===============================================

#calculate local time offset using google's http headers as a baseline
$varServerTime=([DateTimeOffset]::Parse((Get-HTTPHeaders http://www.google.com | Where-Object {$_.Key -eq "Date"}).Value)).UtcDateTime
$varServerEpoch=[int64](($varServerTime)-(get-date "1/1/1970")).TotalSeconds

#get local time
$varLocalEpoch=[int64](([datetime]::UtcNow)-(get-date "1/1/1970")).TotalSeconds

#compare
[int]$varTimeOffset = $varServerEpoch - $varLocalEpoch
if ($varTimeOffset -lt 0) {$varTimeOffset=0-$varTimeOffset}

#get to printing
write-host "     Clock Accuracy Offset  " -NoNewline
if (($varTimeOffset).tostring().length -ge 4) {
    write-host ">15 Min Out" -NoNewline -foregroundcolor Red
    $script:CSToolReport += "! FAILURE: Device time is incorrect by more than fifteen minutes."
    $script:CSToolReport += "           This will render the device unable to communicate via SSL, precluding the Agent from connecting."
} elseif ($varTimeOffset -ge 600) {
    write-host ">10 Min Out" -NoNewline -foregroundcolor Red
    $script:CSToolReport += "! FAILURE: Device time is incorrect by more than ten minutes."
    $script:CSToolReport += "           This will render the device unable to communicate via SSL, precluding the Agent from connecting."
} elseif ($varTimeOffset -ge 121) {
    write-host " >2 Min Out" -NoNewline -foregroundcolor Yellow
    $script:CSToolReport += "! WARNING: Device time is incorrect by two to ten minutes."
    $script:CSToolReport += "           A device with inaccurate time may be unable to communicate via SSL, precluding the Agent from connecting."
} elseif ($varTimeOffset -le 120) {
    write-host "   Accurate" -NoNewline -foregroundcolor Green
    $script:CSToolReport += "+ SUCCESS: Device time is accurate within two minutes. The device and the Agent should be able to communicate via secure channels."
}

write-host "   ||   " -foregroundcolor DarkGray -nonewline

#counterproductive agent policy
write-host "Agent Policy Settings     " -NoNewline

if (!$CSAdmin) {
    write-host "No Admin" -foregroundcolor Red
    $script:CSToolReport+=": UNKNOWN: Tool was unable to check for a counterproductive Agent Policy because it was not run with Administrator-level access."
} else {
    if (($arrXMLFiles | measure-object).count -eq 0) {
        write-host "  Absent" -ForegroundColor Red
        $script:CSToolReport+="! FAILURE: No Policy data was present. Consider re-installing the Agent."
    } else {
        try {
            $arrXMLFiles | ? {$_} | % {
                [xml]$CSSystemXML=Get-Content "$_"
                foreach ($CSPolicySetting in ('PolicyEnableIncomingJobs','PolicyEnableIncomingSupport','PolicyEnableAudits','PolicyTrayVisible')) {
                    $CSSystemXML_Setting=($CSSystemXML.Configuration.userSettings.'CentraStage.Cag.Core.Settings'.setting | where-object {$_.Name -match "$CSPolicySetting" }).value
                    if ($CSSystemXML_Setting -eq 'false') {
                        $script:CSToolReport += "- CAUTION: Setting `"$CSPolicySetting`" is disabled via an Agent Policy. Ensure this was a deliberate action."
                        $CSPolicyAdvisories++
                    }

                }
            }
        } catch {
            $CSPolicyAdvisories++
            $script:CSToolReport+="! FAILURE: The user.config file in $env:SystemRoot\System32\config\systemProfile\appData\Local\CentraStage\{latest}\{latest} appears to be corrupt."
            $script:CSToolReport+="           Consider reinstalling the Agent."
        }

        if ($CSPolicyAdvisories -ge 1) {
            write-host "Advisory" -ForegroundColor Red
        } else {
            write-host "No Issue" -ForegroundColor Green
            $script:CSToolReport += "+ SUCCESS: There are no counterproductive Agent Policies disabling Audits, Support or Jobs targeting this system."
        }
    }
}

#=============================================== new line ===============================================

#web port ok
write-host "     Web Port Check              " -NoNewline
if (test-path "$varProg32\CentraStage\log.txt") {
    if ($(get-content -LiteralPath "$varProg32\CentraStage\log.txt") | select-string -Pattern 'web port ok' | Select-Object -last 1 | select-string -pattern 'false' -quiet) {
        write-host "Failed" -ForegroundColor Red -NoNewline
        $script:CSToolReport+="! FAILURE: The Agent is reporting that its Web Port check is failing, meaning it cannot connect fully to the platform."
        $script:CSToolReport+="           This will cause monitors not to report data, alongside other performance issues."
        $script:CSToolReport+="           Please check that Agent connections are whitelisted properly. You are strongly advised to inform the Support team of this notice."
    } else {
        write-host "   OK!" -ForegroundColor Green -NoNewline
        $script:CSToolReport+="+ SUCCESS: The Agent is reporting that it can connect fully to the platform."
    }
} else {
    write-host "Absent" -ForegroundColor Red -NoNewline
    $script:CSToolReport+="! FAILURE: The Agent log is not present. Consider re-installing the Agent."
}

write-host "   ||   " -foregroundcolor DarkGray -nonewline

#monitoring log
write-host "Monitoring Log" -NoNewline
if (test-path "$env:ProgramData\CentraStage\AEMAgent\DataLog\aemagent.log") {
    if ((Get-ChildItem -Path "$env:ProgramData\CentraStage\AEMAgent\DataLog\aemagent.log").LastWriteTime.Date -eq (Get-Date).Date) {
        write-host "                 OK!" -ForegroundColor Green
        $script:CSToolReport+="+ SUCCESS: The Monitoring Agent's logging data is current."
    } else {
        write-host "             Stalled" -ForegroundColor Red
        $script:CSToolReport+="! FAILURE: The Monitoring Agent appears to have stopped producing logging data. Please inspect AEMAgent.log manually."
    }
} else {
        write-host "              Absent" -ForegroundColor Red
        $script:CSToolReport+="! FAILURE: The Monitoring Agent log is not present. Consider re-installing the Agent."
}

#=============================================== new line ===============================================

#monitoring data
write-host "     Monitoring Data" -NoNewline
if ($varOnDemand -eq 1) {
    if (test-path "$env:ProgramData\CentraStage\AEMAgent\Monitors.json") {
        if ((Get-ChildItem -Path "$env:ProgramData\CentraStage\AEMAgent\Monitors.json").LastWriteTime -gt (get-date).addHours(-24)) {
            write-host "                OK!" -NoNewline -ForegroundColor Green
            $script:CSToolReport+="+ SUCCESS: The Monitoring Agent's monitor data JSON is being kept up-to-date."
        } else {
            Stop-Process -Name AEMAgent -Force -ErrorAction SilentlyContinue 2>&1>$null
            write-host "          Restarted" -NoNewline -ForegroundColor Red
            $script:CSToolReport+="! FAILURE: The Monitoring Agent's monitor data JSON does not appear to be being kept up-to-date. Has the Agent been approved?"
            $script:CSToolReport+="           The Monitoring Agent process (AEMAgent.exe) has been killed. Please wait two minutes and then re-run this test."
        }
    } else {
            write-host "             Absent" -ForegroundColor Red -NoNewline
            $script:CSToolReport+="! FAILURE: The Monitoring Agent's monitor data JSON is not present. Consider re-installing the Agent."
    }
} elseif ($varOnDemand -eq 2) {
    write-host "           OnDemand" -ForegroundColor Yellow -NoNewline
    $script:CSToolReport+=": UNKNOWN: Monitoring Data checks skipped; the Agent is running as OnDemand, so no monitoring is occurring."
} else {
    write-host "           No Admin" -ForegroundColor Red -NoNewline
    $script:CSToolReport+=": UNKNOWN: Monitoring Data checks skipped; as the script was not run as Administrator, the OnDemand check could not run."
}

write-host "   ||   " -foregroundcolor DarkGray -nonewline

#alert queue
write-host "Alert Queue" -NoNewline
if (test-path "$env:ProgramData\CentraStage\AEMAgent\DataLog") {
    If (Get-ChildItem -Path $env:ProgramData\CentraStage\AEMAgent\DataLog\*.alert.dat | Where-Object {$_.LastWriteTime -le (Get-Date).AddMinutes(-5)}) {
        Stop-Process -Name AEMAgent -Force -ErrorAction SilentlyContinue 2>&1>$null
        write-host "              Restarted" -ForegroundColor Red
        $script:CSToolReport+="! FAILURE: The Monitoring Agent appears to be having trouble despatching Alerts from its Alert Queue."
        $script:CSToolReport+="           The Monitoring Agent process (AEMAgent.exe) has been killed. Please wait two minutes and then re-run this test."
    } else {
        write-host "                    OK!" -ForegroundColor Green
        $script:CSToolReport+="+ SUCCESS: The Monitoring Agent appears to be despatching alerts to the platform correctly."
    }
} else {
    write-host "                 Absent" -ForegroundColor Red
    $script:CSToolReport+="! FAILURE: The Monitoring Agent's log repository is not present. Consider re-installing the Agent."
}

#=============================================== new line ===============================================

#PATH
write-host "     PATH                     " -NoNewline
try {
    if ((get-item "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment").GetValueKind("Path").value__ -ne 2) {
        if (!$CSAdmin) {
            $CSPathStatus=1
            $script:CSToolReport+="! FAILURE: The system's PATH variable is not set to REG_SZ_EXPAND (ExpandedString)."
            $script:CSToolReport+="           This will cause PowerShell Components to fail with 'cannot find powershell' errors."
            $script:CSToolReport+="           With Administrative privileges, the tool can attempt to fix this."
        } else {
            $CSPathStatus=2
            $script:CSToolReport+="! FAILURE: The system's PATH variable was not set to REG_SZ_EXPAND (ExpandedString)."
            $script:CSToolReport+="           This will cause PowerShell Components to fail with 'cannot find powershell' errors."
            $script:CSToolReport+="           The tool has attempted to recreate the value and fix the issue."
            #actually do it
            $CSPathContents=(get-itemproperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment").Path
            remove-itemproperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" -Name Path -Force
            New-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" -Name Path -PropertyType ExpandString -Value "$CSPathContents" -Force | Out-Null
        }
    } else {
        $CSPathStatus=4
        $script:CSToolReport+="+ SUCCESS: The system PATH is set to the right value type."
    }
} catch {
    $CSPathStatus=8
    $script:CSToolReport+="! FAILURE: The system has no PATH variable. This will cause issues running PowerShell scripts."
}

#PowerShell path
if (((Get-Process PowerShell -ea 0 | ? {$_.Id -eq $PID}).path | split-path) -ne "$env:SystemRoot\System32\WindowsPowerShell\v1.0") {
    $script:CSToolReport+="! FAILURE: PowerShell.exe is not located in $env:SystemRoot\System32\WindowsPowerShell\v1.0."
    $script:CSToolReport+="  This will stop Datto RMM from being able to run Components. Please correct this on the system."
    $CSPathStatus+=16
}

switch ($CSPathStatus) {
      1 {write-host "Corrupted" -ForegroundColor Red    -NoNewline}
      2 {write-host "Recreated" -ForegroundColor Yellow -NoNewline}
      4 {write-host "      OK!" -ForegroundColor Green  -NoNewline}
      8 {write-host "   Absent" -ForegroundColor Red    -NoNewline}
     17 {write-host "Corrupted" -ForegroundColor Red    -NoNewline}
     18 {write-host "Corrupted" -ForegroundColor Red    -NoNewline}
     20 {write-host "  PS PATH" -ForegroundColor Red    -NoNewline}
     24 {write-host "   Issues" -ForegroundColor Red    -NoNewline}
default {write-host "  Unknown" -ForegroundColor Yellow -NoNewline}
}

write-host "   ||   " -foregroundcolor DarkGray -NoNewline

#registry unicode :: anything outside of x00-xff, except for the trademark symbol, because that's ok somehow
write-host "Registry Validation" -NoNewline

('HKLM:\Software\Microsoft\Windows\Currentversion\Uninstall','HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall','HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall') | % {
    gci $_ | % {
        try {
            $varLoc=$_.name
            gp "Registry::$varLoc" -ea 0 | % {
                if ($_.PSPath -match '[^\x00-\xff\u2122]') {
                    #sound an alert if the registry key name contains invalid unicode
                    $script:CSToolReport+="! FAILURE: Registry key [$($_.PSPath -replace [regex]::Escape('Microsoft.PowerShell.Core\Registry::'))] name contains invalid Unicode"
                    $varRegBad=$true
                }
                
                if ($_.PSObject.Properties.Value -match '[^\x00-\xff\u2122]') {
                    #sound an alert if any values within the key contain data with invalid unicode
                    (gp $_.PSPath -ea 0).PSObject.Properties | ? {$_.name -notmatch '^PS'} | ? {$_.value -match '[^\x00-\xff\u2122]'} | % {
                        $script:CSToolReport+="! FAILURE: Registry value [$varLoc!$($_.name)] contains invalid Unicode [$($_.value)]"
                        $varRegBad=$true
                    }
                }
            }
        } catch {
            #if the key contains a value with malformed DWORD data, parsing will fail :: report the subkey name as access beyond this is denied
            $script:CSToolReport+="! FAILURE: A Registry value in [$varLoc] is invalid and should be removed."
            $varRegBad=$true
        }
    }
}

if ($varRegBad) {
    write-host "      Check Log" -ForegroundColor Red
} else {
    write-host "            OK!" -ForegroundColor Green
    $script:CSToolReport+="+ SUCCESS: Registry uninstall records. No unconventional Unicode found."
}

$script:CSToolReport+=": End of device checks"
$script:CSToolReport+=""

#------------------------------------------------ sub-section: post-check prompts

write-host "     ============================================================================" -foregroundcolor DarkGray
write-host "     Press for NO               [" -nonewline
write-host "ENTER" -foregroundcolor red -nonewline
write-host "]   " -nonewline
write-host "||" -foregroundcolor DarkGray -nonewline
write-host "   Press for YES                  [" -nonewline
write-host "A" -nonewline -foregroundcolor Red
write-host "]"
write-host `r

#display antivirus
if ($varServer) {
    write-host "- Antivirus check skipped: Cannot detect antivirus software on servers." -ForegroundColor Yellow
} else {
    $arrAntivirus=@()
    try {
        Get-wmiObject -nameSpace root/SecurityCenter2 -Class AntivirusProduct -ea stop | % {$arrAntivirus+="$($_.displayName),"}
        if (($arrAntivirus | measure-object).count -eq 0) {
            write-host "- No Antivirus Software detected." -ForegroundColor Red
            $script:CSToolReport+="! FAILURE: No Antivirus was detected. If one is installed, report this error; otherwise, install one!"
        } else {
            $varAntivirus=($arrAntivirus -as [string]).substring(0,$($arrantivirus -as [string]).length-1)
            write-host "- Antivirus Software Detected: $varAntivirus" -ForegroundColor Yellow
            $script:CSToolReport+= ": Antivirus detected on device as $varAntivirus"
        }
    } catch {
        write-host "- WMI Issues prevented checking Antivirus software" -ForegroundColor Red
        $script:CSToolReport+="! FAILURE: Suspected issues with the WMI stopped the script from ascertaining antivirus status"
        $varWMIIssues="Significant"
    }
}

#fix dotnet
$varDecision=read-host "- Analyse/Repair .NET Framework (~5 Min)?"
switch -Regex ($varDecision) {   
    'A|a|Y|y' {
        (New-Object System.Net.WebClient).DownloadFile("https://download.microsoft.com/download/2/B/D/2BDE5459-2225-48B8-830C-AE19CAF038F1/NetFxRepairTool.exe", "$varScriptDir\NetFXRepairTool.exe")
        if (!$script:varResultDir) {
            makeFolder
        }

        Start-Process "$varScriptDir\NetFxRepairTool.exe" -ArgumentList "/q /n /l `"$script:varResultDir`""
        while (get-process FixDotNet,NetFXRepairTool -ea 0) {
            write-host "`r-- Waiting for .NET Repair Tool to finish [Current time is $(get-date -Format 'HH:mm.ss')]" -ForegroundColor Cyan -NoNewline
            start-sleep -seconds 3
        }
        write-host "`r- DotNet Repair Tool has completed actions.                                         " -ForegroundColor Green
        $script:CSToolReport+= ": MENTION: Microsoft .NET Repair tool was run on the Endpoint."
    } default {
        #NOP
    }
}

#attempt to repair WMI (october 2025; thanks to JK/datto labs)
if ($CSAdmin) {
    if ($varWMIIssues) {
        $varWMITest=start-process "winmgmt" -ArgumentList "/verifyrepository" -NoNewWindow -wait -PassThru -RedirectStandardOutput "NUL"
        if ($varWMITest.ExitCode -eq 0) {
            $varWMIIssues="Potential"
            $script:CSToolReport+="! NOTICE: Potential WMI issues were discovered"
        }
    } else {
        $varWMIIssues="No"
        $script:CSToolReport+="- No WMI issues were discovered"
    }
    $varDecision=read-host "- Attempt to fix the WMI? ($varWMIIssues issues detected)"

    switch -Regex ($varDecision) {
        'A|a|Y|y' {
            if ($varWMIIssues -eq 'Significant') {
                $script:CSToolReport+="! NOTICE: Significant WMI issues were discovered"
                #salvage WMI
                $script:CSToolReport+="-------------------------------------"
                $script:CSToolReport+=& winmgmt /salvagerepository
                $script:CSToolReport+="-------------------------------------"
            }

            #reregister MOFs
            if (!(test-path "$env:windir\System32\wbem")) {
                $script:CSToolReport+="! FAILURE: $env:windir\System32\WBEM is absent. The WMI will not function."
                write-host "! ERROR: WBEM Folder is absent. This device is beyond repair by this script." -ForegroundColor Red
            } else {
                if ((gci "$env:windir\System32\wbem\*.mof" -ea 0).count -eq 0) {
                    $script:CSToolReport+="! FAILURE: $env:windir\System32\WBEM contains no MOF files. The WMI will not function."
                    write-host "! ERROR: WBEM Folder contains no MOF files. This device is beyond repair by this script." -ForegroundColor Red
                } else {
                    #iterate through MOF files and recompile them
                    [int]$varMOFErrors=0
                    $varWMISpam=@()
                    gci "$env:windir\System32\wbem\*.mof" -ea 0 | ? {$_} | % {
                        $varWMISpam+=& mofcomp.exe $_.FullName
                        if ($LASTEXITCODE -ne 0) {
                            $script:CSToolReport+="! FAILURE: [$($_.FullName)] failed MOF compilation. This indicates an issue with this file which is causing WMI problems."
                            $varMOFErrors++
                        }
                    }
                    #put all the useful data from mofcomp into the output log
                    $script:CSToolReport+="-------------------------------------"
                    $varWMISpam | ? {$_ -notmatch 'Microsoft'} | % {
                        $script:CSToolReport+=$_
                        if ($_ -match '\!$') {
                            $script:CSToolReport+="---"
                        }
                    }
                    $script:CSToolReport+="-------------------------------------"

                    if ($varMOFErrors -eq 0) {
                        $script:CSToolReport+="+ SUCCESS: Attempts to repair WMI appear to have been successful."
                        write-host "- OK: WMI repair has completed successfully."
                    } else {
                        $script:CSToolReport+="! FAILURE: Attempts to repair WMI appear to have been unsuccessful."
                        write-host "! NOTICE: Attempts to repair WMI may not have been successful. Please check output log." -ForegroundColor Yellow
                    }
                }
            }
        } default {
            #NOP
        }
    }
} else {
    write-host ": Cannot check or repair WMI (No admin access)"
    $script:CSToolReport+="- Unable to check-over or repair WMI; Admin access was not granted"
}

#attempt to repair certificates (for PS3.0+)
if ((Get-Host).version.major -ge 3) {
    $varDecision=read-host "- Re-download and merge root certificates from Windows Update?"
}

switch -Regex ($varDecision) {
    'A|a|Y|y' {
        write-host "- Downloading auth roots from https://aka.ms/CTLDownload..."
        (New-Object System.Net.WebClient).DownloadFile("https://aka.ms/CTLDownload","$PWD\authrootstl.cab")
        if (!(test-path "$PWD\authrootstl.cab")) {
            write-host "! ERROR: Unable to download auth roots. Please ensure firewall access."
        } else {
            #expand cab to expose authroot.stl
            Expand -F:* authrootstl.cab "$PWD" -r | Out-Null
            #verify it
            if (!(test-path "$PWD\authroot.stl")) {
                write-host "! ERROR: Unable to expand auth roots. Please ensure firewall access."
            } else {
                $varChain=New-Object -TypeName System.Security.Cryptography.X509Certificates.X509Chain
                $varChain.Build((Get-AuthenticodeSignature -FilePath "authroot.stl").SignerCertificate) | out-null
                if (!(Test-Certificate (Get-AuthenticodeSignature "$PWD\authroot.stl").SignerCertificate)) {
                    write-host "! ERROR: Unable to verify Auth roots (1). Aborting operation."
                } else {
                    if (($varChain.chainElements | ? {$_.certificate.subject -match 'Microsoft Certificate List CA 2011'} | % {$_.certificate}).thumbprint -ne 'B11264C19BE7DAA8C9E989176AE98961FADE31CF') {
                        write-host "! ERROR: Unable to verify Auth roots (2). Aborting operation."
                    } else {
                        Import-Certificate authroot.stl -CertStoreLocation Cert:\LocalMachine\Root | Out-Null
                        write-host "- OK: New Auth roots imported."
                    }
                }
            }
        }
    } default {
        #NOP
    }
}

#closeout
write-host `r
write-host "Agent Health and Endpoint Checks completed." -ForegroundColor Cyan
write-host "Press [" -NoNewline; write-host "ENTER" -nonewline -ForegroundColor Red; write-host "] to collect the tool's logging data." -NoNewline
$HOST.UI.RawUI.FlushInputBuffer()
$choiceInput = read-host
switch ($choiceInput) {
    default {
        clear-host
    }
}

# ==================================================================== PAGE THREE ===================================================================

write-host "Page 3: Data"
if ($CSAdmin) {
    write-host "Tool is being run as an Administrator    " -ForegroundColor Cyan
} else {
    write-host "Tool is not being run as an Administrator" -ForegroundColor Red
}
write-Host "============================="
write-host "                               -== Data Collection ==-" -foregroundcolor Green
write-host "`r"

#conclude the log
$script:CSToolReport+= ": Tool finished actions at $(Get-Date)."

#------------------------------------------------ sub-section: collecting and archiving log data

if (!$CSAdmin) {
    write-host "- Copy all Agent log files to Health Check Tool results directory?"
    write-host "  (Tool cannot gather Operational files without Admin permissions.)" -ForegroundColor yellow
} else {
    write-host "- Copy all Agent logging and Operational files to Health Check Tool results directory?"
}
write-host "  This will download a portable version of 7-zip if it is not installed." -ForegroundColor Yellow
write-host "  A CMD window will briefly appear during the archiving process." -ForegroundColor Yellow

write-host "  [ENTER]" -NoNewline -foregroundcolor Red; write-host "/No, " -NoNewline; write-host "[A]" -NoNewline -foregroundcolor Red; write-host "/Yes: " -NoNewline
$HOST.UI.RawUI.FlushInputBuffer()
$choiceInput = read-host

switch -Regex ($choiceInput) {
    'A|a|Y|y' {
        #get 7-zip
        if (test-path "$env:ProgramFiles\7-zip\7z.exe") {
            #search for native 7-zip
            $var7z="$env:ProgramFiles\7-zip\7z.exe"
        } elseif (test-path "$varProg32\7-zip\7z.exe") {
            #search for WoW 7-zip
            $var7z="$varProg32\7-zip\7z.exe"
        } elseif (test-path "$env:ProgramData\CentraStage\Temp\7z.exe") {
            $var7z="$env:ProgramData\CentraStage\Temp\7z.exe"
        } else {
            #download an MVP from our servers
            (new-object System.Net.WebClient).DownloadFile("https://storage.centrastage.net/7z-min-may22.exe","$PWD\7z-min-may22.exe")
            if (!(test-path "$PWD\7z-min-may22.exe" -ea 0)) {
                write-host "`r"
                write-host "! ERROR: A serious issue has occurred (7-zip could not be downloaded)."
                write-host "  Please ensure https://storage.centrastage.net is allowlisted."
                write-host "  Execution cannot continue. Strike any key to exit."
                cmd /c pause
                exit 1
            }
            if (("$pwd\7z-min-may22.exe" | toSHA256) -ne '9B56E8E175DAEA52FEDF0137933A29961F6417C928D4A210C9E8DBCB0D685691') {
                write-host "`r"
                write-host "! ERROR: A serious issue has occurred."
                write-host "  The script attempted to download 7-zip from a secure Datto RMM location,"
                write-host "  but the downloaded file had a different file hash from what was expected."
                write-host "  Please ensure device connectivity to https://storage.centrastage.net."
                write-host "  If issues persist, please contact support."
                write-host "  Execution cannot continue. Strike any key to exit."
                cmd /c pause
                exit
            } else {
                cmd /c "`"$varScriptDir\7z-min-may22.exe`" -y -o`"$env:ProgramData\CentraStage\Temp`""
                if (("$env:ProgramData\CentraStage\Temp\7z.exe" | toSHA256) -ne 'ED24ED04B5D4A20B3F50FC088A455195C756D7B5315D1965E8C569472B43D939') {
                    write-host "! ERROR: A serious issue has occurred."
                    write-host "  The script attempted to download 7-zip from a secure Datto RMM location,"
                    write-host "  but the downloaded file had a different file hash from what was expected."
                    write-host "  Please ensure device connectivity to https://storage.centrastage.net."
                    write-host "  If issues persist, please contact support."
                    write-host "  Execution cannot continue. Strike any key to exit."
                } else {
                    $var7z="$env:ProgramData\CentraStage\Temp\7z.exe"
                }
            }
        }

        #gather log files :: make directories
        if (!$script:varResultDir) {makeFolder}
        new-item "$script:varResultDir\AgentLogs\" -type directory -Force | out-null
        new-item "$script:varResultDir\AgentLogs\Config" -type directory -Force | out-null
        new-item "$script:varResultDir\AgentLogs\AppData" -type directory -Force | out-null
        new-item "$script:varResultDir\AgentLogs\ProgFiles" -type directory -Force | out-null

        #config 1
        Copy-Item -Path "C:\Windows\System32\config\systemprofile\AppData\Local\CentraStage" -Recurse -Destination "$script:varResultDir\AgentLogs\Config"
        if (test-path "C:\Windows\SysWOW64\config\systemprofile\AppData\Local\CentraStage" -ea 0) {
            new-item "$script:varResultDir\AgentLogs\Config64" -type directory -Force | out-null
            Copy-Item -Path "C:\Windows\SysWOW64\config\systemprofile\AppData\Local\CentraStage" -Recurse -Destination "$script:varResultDir\AgentLogs\Config64"
        }

        #config 2 :: get ALL programdata directories (may 2024)
        gci "$env:ProgramData\CentraStage*" | ? {$_.PSIsContainer} | % {
            $varName=$_.name
            new-item "$script:varResultDir\AgentLogs\AppData\$varName" -type directory -Force | out-null
            gci $_ -Recurse | ? {$_.name -match '\.(xml|log|txt|config|json|dat)$'} | Copy-Item -Destination "$script:varResultDir\AgentLogs\AppData\$varName" -Container -ErrorAction SilentlyContinue
        }

        #program files
        Get-ChildItem -Path "$varProg32\Centrastage" -Recurse | ? { $_.Name -match "^log\." } | Copy-Item -Destination "$script:varResultDir\AgentLogs\ProgFiles"

        #archive it
        $varLogArchive="AHC-$env:ComputerName-AgentLogs-$(EpochTime).zip"
        start-process "$var7z" -argumentlist  "a `"$varLogArchive`" `"$script:varResultDir`""

        #clean up
        start-sleep -Seconds 5
        remove-item "$script:varResultDir\*" -Recurse -Force -ea 0 | out-null
        start-sleep -Seconds 5
        remove-item "$script:varResultDir" -Recurse -Force -ea 0 | out-null
    } default {
        #do nothing
    }
}

write-host `r
#saving a text report is no longer optional
$varReportName="AHC-$env:computername-Report-$(EpochTime).log"
$script:CSToolReport | % {
    add-content -Value $_ -Path "$PWD\$varReportName"
}
if ($var7z) {
	#add this to the archive
    Start-Process "$var7z" -argumentlist "a `"$varLogArchive`" `"$varReportName`""

    write-host "- Report file has been created and added to the existing logfile archive." -ForegroundColor Green
} else {
    write-host "- Report file has been created." -ForegroundColor Green
}
write-host "  Please consult it for more information on any errors which were listed."

#------------------------------------------------ sub-section: closeout

write-host "`r"
write-host "                               -== Scan Completed! ==-" -foregroundcolor Green
write-host `r
write-host "Thank you for using the Agent Health Check Tool. We hope you found it useful."
write-host "Any data collected by the tool can be found in the same directory as the tool itself."
write-host `r
write-host "If you are submitting data for the Support team, please preserve it in its ZIP archive"
write-host "and upload it and any related data to " -nonewline
write-host "http://dat.to/ahcul." -ForegroundColor Cyan
write-host "Only the Support team will be able to access uploaded data." -foregroundcolor Green
write-host `r
write-host "Press [" -nonewline; write-host "ENTER" -NoNewline -foregroundcolor Red
write-host "] to exit, or [" -NoNewline
write-host "A" -foregroundcolor red -nonewline
write-host "] to upload log files: " -nonewline
$HOST.UI.RawUI.FlushInputBuffer()
$choiceInput = read-host
switch -Regex ($choiceInput) {
    default {
        exit
    } 'A|a|Y|y' {
        start 'http://dat.to/ahcul'
        write-host "Log Upload website opened. Closing Tool..."
        start-sleep 5
        exit
    }
}